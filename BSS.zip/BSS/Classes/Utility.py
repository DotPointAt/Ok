import json
import os
import random

import Configuration


class Utility:

    def timerMath(self, timer_start_date, timer_end_date):
        if timer_end_date == "dailyoffer":
            from datetime import datetime
            time_sec = 86400 - (3600 * int(datetime.today().strftime('%H'))) + (60 * int(datetime.today().strftime('%M'))) + int(datetime.today().strftime('%S'))
        else:
            import datetime
            import time
            timer_start = datetime.datetime(timer_start_date[0], timer_start_date[1], timer_start_date[2], timer_start_date[3], timer_start_date[4], timer_start_date[5])
            timer_end = datetime.datetime(timer_end_date[0], timer_end_date[1], timer_end_date[2], timer_end_date[3], timer_end_date[4], timer_end_date[5])
            timer_now = datetime.datetime.now()
            if timer_now > timer_start:
                if timer_now < timer_end:
                    time_sec = (timer_end - timer_now).total_seconds()
                else: time_sec = -1
            else: time_sec = -1
        return int(time_sec)

    def timerGlobalHour(self, timer):
        from datetime import datetime
        timer_max = 86400
        timer_now = (0 * int(datetime.today().strftime('%d'))) + (3600 * int(datetime.today().strftime('%H'))) + (60 * int(datetime.today().strftime('%M'))) + int(datetime.today().strftime('%S'))
        timer = timer_max - timer_now
        return timer

    def consoleLog(msg):
        from datetime import datetime
        second = str(datetime.now().second)
        minute = str(datetime.now().minute)
        hour = str(datetime.now().hour)
        day = str(datetime.now().day)
        month = str(datetime.now().month)
        if int(second) < 10: second = "0" + second
        if int(minute) < 10: minute = "0" + minute
        if int(hour) < 10: hour = "0" + hour
        if int(day) < 10: day = "0" + day
        if int(month) < 10: month = "0" + month
        dataTime = (day + "." + month + " " + hour + ":" + minute + ":" + second + " - ")
        msgStr = (dataTime + msg)
        print(msgStr)
        file = open(("log.txt"), "r")
        fileLog = file.read()
        file.close()
        msgLog = fileLog.split("\n")
        msgLog.append(msgStr)
        file = open(("log.txt"), "w")
        file.write("") 
        file.close()

    def timerGetTime(self, timer):
        SkinsID = [
            {"SkinID": 2, "BrawlerID": 1, "Price": 19, "OldPrice": 29}, # Colt Rockstar
            {"SkinID": 15, "BrawlerID": 8, "Price": 19, "OldPrice": 29}, # Nita Panda
            {"SkinID": 27, "BrawlerID": 6, "Price": 19, "OldPrice": 29}, # Barley Gold
            {"SkinID": 109, "BrawlerID": 27, "Price": 19, "OldPrice": 29}, # 8-Bit Classic
            {"SkinID": 29, "BrawlerID": 0, "Price": 19, "OldPrice": 29}, # Bandita Shelly
            {"SkinID": 277, "BrawlerID": 45, "Price": 19, "OldPrice": 29}, # Stu Starr
            {"SkinID": 245, "BrawlerID": 14, "Price": 19, "OldPrice": 29}, # Bo Wairor
            {"SkinID": 137, "BrawlerID": 32, "Price": 19, "OldPrice": 29}, # Bo Wairor
            {"SkinID": 176, "BrawlerID": 34, "Price": 19, "OldPrice": 29}, # Bo Wairor
            {"SkinID": 108, "BrawlerID": 15, "Price": 19, "OldPrice": 29}, # Bo Wairor
            {"SkinID": 167, "BrawlerID": 30, "Price": 19, "OldPrice": 29}, # Bo Wairor
            {"SkinID": 103, "BrawlerID": 1, "Price": 19, "OldPrice": 29}, # Bo Wairor
            {"SkinID": 148, "BrawlerID": 8, "Price": 59, "OldPrice": 79}, # Hita Coala
            {"SkinID": 292, "BrawlerID": 38, "Price": 59, "OldPrice": 79}, # Hita Coala
            {"SkinID": 346, "BrawlerID": 8, "Price": 59, "OldPrice": 79}, # Hita Coala
            {"SkinID": 5, "BrawlerID": 3, "Price": 59, "OldPrice": 79}, # Brock Sand
            {"SkinID": 92, "BrawlerID": 6, "Price": 59, "OldPrice": 79}, # Barley Canada
            {"SkinID": 104, "BrawlerID": 25, "Price": 59, "OldPrice": 79}, # Carl Hog
            {"SkinID": 47, "BrawlerID": 7, "Price": 59, "OldPrice": 79}, # Jass Summer
            {"SkinID": 179, "BrawlerID": 16, "Price": 59, "OldPrice": 79}, # Pam Summer
            {"SkinID": 202, "BrawlerID": 32, "Price": 59, "OldPrice": 79}, # Pam Summer
            {"SkinID": 159, "BrawlerID": 0, "Price": 59, "OldPrice": 79}, # Pam Summer
            {"SkinID": 326, "BrawlerID": 1, "Price": 59, "OldPrice": 79}, # Pam Summer
            {"SkinID": 318, "BrawlerID": 10, "Price": 59, "OldPrice": 79}, # Pam Summer
            {"SkinID": 158, "BrawlerID": 18, "Price": 59, "OldPrice": 79}, # Pam Summer
            {"SkinID": 20, "BrawlerID": 12, "Price": 59, "OldPrice": 79}, # Pam Summer
            {"SkinID": 44, "BrawlerID": 7, "Price": 109, "OldPrice": 149}, # Jass Knite
            {"SkinID": 26, "BrawlerID": 4, "Price": 109, "OldPrice": 149}, # Rico Gold
            {"SkinID": 68, "BrawlerID": 4, "Price": 109, "OldPrice": 149}, # Rico Popcorn
            {"SkinID": 171, "BrawlerID": 4, "Price": 109, "OldPrice": 149}, # Rico Wairor
            {"SkinID": 98, "BrawlerID": 14, "Price": 109, "OldPrice": 149}, # Bo Mexa
            {"SkinID": 101, "BrawlerID": 12, "Price": 109, "OldPrice": 149}, # Crow Mexa
            {"SkinID": 172, "BrawlerID": 21, "Price": 109, "OldPrice": 149}, # Gene Evil
            {"SkinID": 96, "BrawlerID": 5, "Price": 109, "OldPrice": 149}, # Gene Evil
            {"SkinID": 160, "BrawlerID": 9, "Price": 109, "OldPrice": 149}, # Gene Evil
            {"SkinID": 30, "BrawlerID": 10, "Price": 109, "OldPrice": 149}, # Gene Evil
            {"SkinID": 94, "BrawlerID": 14, "Price": 159, "OldPrice": 199}, # Bo Mexa
            {"SkinID": 95, "BrawlerID": 12, "Price": 159, "OldPrice": 199}, # Crow Mexa
            {"SkinID": 99, "BrawlerID": 14, "Price": 239, "OldPrice": 299}, # Crow Mexa
            {"SkinID": 97, "BrawlerID": 9, "Price": 239, "OldPrice": 299}, # Crow Mexa
            {"SkinID": 100, "BrawlerID": 12, "Price": 239, "OldPrice": 299} # Gene Evil
        ]
        if timer == "1bannertime": x = Utility.timerMath(self, [1970, 1, 1, 0, 0, 0], [2024, 3, 14, 0, 0, 0])
        elif timer == "2bannertime": x = Utility.timerMath(self, [2023, 12, 30, 0, 0, 0], [2024, 3, 14, 0, 0, 0])
        elif timer == "3bannertime": x = Utility.timerMath(self, [2024, 1, 13, 0, 0, 0], [2024, 3, 14, 0, 0, 0])
        elif timer == "1banner": x = [["5", "14", "9", "34"], ["9", "34"]]
        elif timer == "2banner": x = [["1", "43", "17", "40"], ["17", "40"]]
        elif timer == "3banner": x = [["15", "27", "10", "37"], ["10", "37"]]
        elif timer == "common_brawlers": x = [["27", "14", "9", "43", "1", "13", "15"], ["50", "22", "8", "3", "16", "7", "21", "4"], ["35", "38", "39", "41"]]
        elif timer == "skinsid": x = SkinsID
        elif timer == "iconsid": x = [89, 90, 91, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100]
        elif timer == "timerbp1": x = Utility.timerMath(self, [1970, 1, 1, 0, 0, 0], [2024, 6, 6, 12, 0, 0])
        elif timer == "weeklyquest1": x = ["penny_skin2", 28, 0, 5, 19]
        elif timer == "weeklyquest2": x = ["nita_skin1", 28, 0, 5, 8]
        elif timer == "weeklyquest3": x = ["dino_skin1", 28, 0, 5, 9]
        elif timer == "week1": x = Utility.timerMath(self, [1970, 1, 1, 0, 0, 0], [2023, 12, 23, 0, 0, 0])
        elif timer == "week2": x = Utility.timerMath(self, [2023, 12, 23, 0, 0, 0], [2024, 3, 14, 0, 0, 0])
        elif timer == "week3": x = Utility.timerMath(self, [2023, 12, 30, 0, 0, 0], [2024, 3, 14, 0, 0, 0])
        elif timer == "week4": x = Utility.timerMath(self, [2024, 1, 6, 0, 0, 0], [2024, 3, 14, 0, 0, 0])
        elif timer == "week5": x = Utility.timerMath(self, [2024, 1, 13, 0, 0, 0], [2024, 3, 14, 0, 0, 0])
        elif timer == "week6": x = Utility.timerMath(self, [2024, 1, 20, 0, 0, 0], [2024, 3, 14, 0, 0, 0])
        elif timer == "weekname1": x = "week1"
        elif timer == "weekname2": x = "week2"
        elif timer == "weekname3": x = "week3"
        elif timer == "weekname4": x = "week4"
        elif timer == "weekname5": x = "week5"
        elif timer == "weekname6": x = "week6"
        elif timer == "weekname": x = "week"
        return x

    def leagueGetRank(self, wins, i):
        try:
            if wins[i] < 4:
                return 1
            elif 4 <= wins[i] <= 9:
                return 2
            elif 10 <= wins[i] <= 19:
                return 3
            elif 20 <= wins[i] <= 29:
                return 4
            elif 30 <= wins[i] <= 39:
                return 5
            elif 40 <= wins[i] <= 59:
                return 6
            elif 60 <= wins[i] <= 79:
                return 7
            elif 80 <= wins[i] <= 99:
                return 8
            elif 100 <= wins[i] <= 129:
                return 9
            elif 130 <= wins[i] <= 159:
                return 10
            elif 160 <= wins[i] <= 189:
                return 11
            elif 190 <= wins[i] <= 239:
                return 12
            elif 240 <= wins[i] <= 299:
                return 13
            elif 300 <= wins[i] <= 379:
                return 14
            elif 380 <= wins[i] <= 439:
                return 15
            elif 440 <= wins[i] <= 539:
                return 16
            elif 540 <= wins[i] <= 639:
                return 17
            elif 640 <= wins[i] <= 799:
                return 18
            elif wins[i] > 799:
                return 19
        except:
            return 0


    def parseFields(fields: dict):
        #print()
        #for typeName,value in fields.items():
        #    print(f"{typeName}: {value}")
        #print()
        pass

    def dumpPacket(buffer, packetID):
        from Classes.Logic.LogicLaserMessageFactory import LogicLaserMessageFactory
        packet_name = LogicLaserMessageFactory.getMessageName(packetID)
        if (packetID not in Configuration.settings["Blacklist"] and len(buffer) != 0):
            if (not os.path.exists(f"HexDumpV{Configuration.settings['DumpMajor']}/" + packet_name)):
                os.mkdir(f"HexDumpV{Configuration.settings['DumpMajor']}/" + packet_name)

            with open((f'HexDumpV{Configuration.settings["DumpMajor"]}/' + packet_name + '/' + str(time.time()) + '_' + packet_name + '.bin'), 'wb') as packet_file:
                packet_file.write(buffer)
                packet_file.close()

    def getContentUpdaterInfo():
        return open(f"./ContentUpdater/lastversion.txt", 'r').read().split('...')

    def getFingerprintData(resourceSha):
        return json.dumps(json.loads(open(f"./ContentUpdater/Update/{resourceSha}/fingerprint.json", 'r').read()))

    def getRandomID():
        id = []
        id.append(int(''.join([str(random.randint(0, 9)) for _ in range(2)])))
        id.append(int(''.join([str(random.randint(0, 9)) for _ in range(8)])))
        return id
