from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler

import json
from Classes.Packets.PiranhaMessage import PiranhaMessage


class ListBrawlTvChannelsMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        self.readBoolean()
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()

        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
     
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(24701, fields, cryptoInit, calling_instance.player)

    def getMessageType(self):
        return 14700

    def getMessageVersion(self):
        return self.messageVersion