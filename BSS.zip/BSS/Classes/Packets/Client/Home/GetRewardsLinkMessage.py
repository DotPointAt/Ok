from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage

from Database.DatabaseHandler import DatabaseHandler
from Static.StaticData import StaticData
import json

class GetRewardsLinkMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Link"] = self.readString()
        print(fields["Message"])
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        


      
            

        db_instance.updatePlayerData(player_data, calling_instance)
        	
    def getMessageType(self):
        return 17683

    def getMessageVersion(self):
        return self.messageVersion