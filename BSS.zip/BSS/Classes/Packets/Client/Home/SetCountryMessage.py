from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class SetCountryMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        


    def encode(self, fields):
        self.writeVInt(fields["idk"])
        self.writeVInt(fields["idk1"])
        self.writeVInt(fields["idk2"])



    def decode(self):
        fields = {}
        fields["idk"] = self.readVInt()
        fields["idk1"] = self.readVInt()
        fields["idk2"] = self.readVInt()
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 201}
        db_instance = DatabaseHandler()
        playerData = db_instance.getPlayer(calling_instance.player.ID)
        db_instance.updatePlayerData(playerData, calling_instance)
        Messaging.sendMessage(24111, fields, cryptoInit)

    def getMessageType(self):
        return 12998

    def getMessageVersion(self):
        return self.messageVersion