from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class SetInvitesBlockedMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        


    def encode(self, fields):
        self.writeVInt(fields["State"])




    def decode(self):
        fields = {}
        fields["State"] = self.readVInt()
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 213}
        db_instance = DatabaseHandler()
        playerData = db_instance.getPlayer(calling_instance.player.ID)
        db_instance.updatePlayerData(playerData, calling_instance)
        Messaging.sendMessage(24111, fields, cryptoInit)

    def getMessageType(self):
        return 14777

    def getMessageVersion(self):
        return self.messageVersion