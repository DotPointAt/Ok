from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
import Configuration
from Database.DatabaseHandler import DatabaseHandler
from Static.StaticData import StaticData
import json

class SetSupportedCreatorMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Message"] = self.readString()
        print(fields["Message"])
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        db_instance = DatabaseHandler()
        player_data = db_instance.getPlayer(calling_instance.player.ID)
        
        if fields["Message"].lower() in Configuration.settings["CreatorsCodesKittys"]:
            player_data["Gems"] += 100
            player_data["ContentCreator"] = fields["Message"].lower()
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["PlayerID"] = calling_instance.player.ID
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["Message"].lower() in Configuration.settings["CreatorsCodesCats"]:
            player_data["ContentCreator"] = fields["Message"].lower()
            player_data["Gems"] += 100
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["PlayerID"] = calling_instance.player.ID
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["Message"] == "MMA":
            player_data["ContentCreator"] = "MMA"
            player_data["Gems"] += 25
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        elif fields["Message"] == "Zloy Wester":
            player_data["ContentCreator"] = "Zloy Wester"
            player_data["Gems"] += 25
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        elif fields["Message"] == "4e5462bf6240":
            player_data["ContentCreator"] = "4e5462bf6240"
            player_data["BrawlPass"] = True
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24104, fields, cryptoInit)
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        elif fields["Message"] == "lastvontik":
            player_data["ContentCreator"] = "lastvontik"
            player_data["Gems"] += 25
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        elif fields["Message"] == "TT:Sunex":
            player_data["ContentCreator"] = "TT:Sunex"
            player_data["Gems"] += 25
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        elif fields["Message"] == "":
            player_data["ContentCreator"] = ""
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        elif fields["Message"] == "KIT":
            player_data["ContentCreator"] = "KIT"
            player_data["Gems"] += 25
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24111, fields, cryptoInit)
            
      
        elif fields["Message"] == "666":
            player_data["ContentCreator"] = "666"
            player_data["Coins"] = 666
            player_data["Name"] = "666"
            player_data["Gems"] = 666
            player_data["Trophies"] = 666
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 215}
            fields["SupportedCreator"] = fields["Message"]
            Messaging.sendMessage(24104, fields, cryptoInit)
            
        
        else:
            fields["jopa"] = player_data["ContentCreator"]
            Messaging.sendMessage(28686, fields, cryptoInit)
            

        db_instance.updatePlayerData(player_data, calling_instance)
        	
    def getMessageType(self):
        return 18686

    def getMessageVersion(self):
        return self.messageVersion