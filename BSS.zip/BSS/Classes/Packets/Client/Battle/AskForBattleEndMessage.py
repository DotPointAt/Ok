from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Logic.LogicStarrDropData import starrDropOpening
import json
from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
import json
import Configuration
from Classes.Packets.PiranhaMessage import PiranhaMessage

OwnedBrawlersLatest = {
        0: {'CardID': 0, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        1: {'CardID': 4, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        2: {'CardID': 8, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        3: {'CardID': 12, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        4: {'CardID': 16, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        5: {'CardID': 20, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        6: {'CardID': 24, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        7: {'CardID': 28, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        8: {'CardID': 32, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        9: {'CardID': 36, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        10: {'CardID': 40, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        11: {'CardID': 44, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        12: {'CardID': 48, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        13: {'CardID': 52, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        14: {'CardID': 56, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        15: {'CardID': 60, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        16: {'CardID': 64, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        17: {'CardID': 68, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        18: {'CardID': 72, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        19: {'CardID': 95, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        20: {'CardID': 100, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        21: {'CardID': 105, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        22: {'CardID': 110, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        23: {'CardID': 115, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        24: {'CardID': 120, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        25: {'CardID': 125, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        26: {'CardID': 130, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        27: {'CardID': 177, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        28: {'CardID': 182, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        29: {'CardID': 188, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        30: {'CardID': 194, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        31: {'CardID': 200, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        32: {'CardID': 206, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        34: {'CardID': 218, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        35: {'CardID': 224, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        36: {'CardID': 230, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        37: {'CardID': 236, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        38: {'CardID': 279, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        39: {'CardID': 296, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        40: {'CardID': 303, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        41: {'CardID': 320, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        42: {'CardID': 327, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        43: {'CardID': 334, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        44: {'CardID': 341, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        45: {'CardID': 358, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        46: {'CardID': 365, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        47: {'CardID': 372, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        48: {'CardID': 379, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        49: {'CardID': 386, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        50: {'CardID': 393, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        51: {'CardID': 410, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        52: {'CardID': 417, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        53: {'CardID': 427, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        54: {'CardID': 434, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        56: {'CardID': 448, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        57: {'CardID': 466, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        58: {'CardID': 474, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        59: {'CardID': 491, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        60: {'CardID': 499, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        61: {'CardID': 507, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        62: {'CardID': 515, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        63: {'CardID': 523, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        64: {'CardID': 531, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        65: {'CardID': 539, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        66: {'CardID': 547, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        67: {'CardID': 557, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        68: {'CardID': 565, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        69: {'CardID': 573, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        70: {'CardID': 581, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        71: {'CardID': 589, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        72: {'CardID': 597, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        73: {'CardID': 605, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        74: {'CardID': 619, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        75: {'CardID': 633, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        76: {'CardID': 642, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        77: {'CardID': 655, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
    }

class AskForBattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["ResultTeam"] = self.readVInt()
        fields["Result"] = self.readVInt()
        fields["Rank"] = self.readVInt()
        fields["MapID"] = self.readDataReference()
        fields["HeroesCount"] = self.readVInt()
        fields["Heroes"] = []
        for i in range(fields["HeroesCount"]): fields["Heroes"].append({"Brawler": {"ID": self.readDataReference(), "SkinID": self.readDataReference()}, "Team": self.readVInt(), "IsPlayer": self.readBoolean(), "PlayerName": self.readString()})
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        if fields["MapID"][1] in Configuration.settings["ChallengeMaps"]:
        	fields["ChallengeVariation"] = Configuration.settings["ChallengeVariation"]
        else:
        	fields["ChallengeVariation"] = -1
        for heroEntry in fields["Heroes"]:
        	if heroEntry["IsPlayer"]:
        		for i,v in player_data["OwnedBrawlers"].items():
        		  			if v["CardID"] == OwnedBrawlersLatest[heroEntry["Brawler"]["ID"][1]]["CardID"]:
        		  				if fields["ResultTeam"] == 0 and fields["HeroesCount"] == 6:
        		  					v["Trophies"] += 80
        		  					v["Mastery"] += 1000
        		  				if fields["ResultTeam"] == 1 and fields["HeroesCount"] == 6:
        		  					v["Trophies"] += 80
        		  					v["Mastery"] += 0
        		  				if fields["ResultTeam"] == 2 and fields["HeroesCount"] == 6:
        		  					v["Trophies"] += 0
        		  					v["Mastery"] += 0
        		  				if fields["ResultTeam"] == 0 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [642]:
        		  					v["Trophies"] += 110
        		  					v["Mastery"] += 1000
        		  				if fields["ResultTeam"] == 1 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [642]:
        		  					v["Trophies"] += 110
        		  					v["Mastery"] += 0
        		  				if fields["ResultTeam"] <= 2 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [431]:
        		  					v["Trophies"] += 70
        		  					v["Mastery"] += 1000
        		  				if fields["ResultTeam"] >= 3 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [431]:
        		  					v["Trophies"] -= 15
        		  					v["Mastery"] += 0
        		  				if fields["ResultTeam"] <= 2 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [430]:
        		  					v["Trophies"] += 80
        		  					v["Mastery"] += 1000
        		  				if fields["ResultTeam"] >= 5 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [430]:
        		  					v["Trophies"] += 80
        		  					v["Mastery"] += 0
        		  					
        		  				if v["Trophies"] > v["HighestTrophies"]:
        		  					v["HighestTrophies"] = v["Trophies"]
        		  					
        		  					#три на три режимы
        if fields["ResultTeam"] == 0 and fields["HeroesCount"] == 6:
            player_data["threevsthreewins"] += 1
            player_data["Trophies"] += 80
            player_data["HighestTrophies"] += 80
    	
        if fields["ResultTeam"] == 1 and fields["HeroesCount"] == 6:

            player_data["Trophies"] += 80
            player_data["HighestTrophies"] += 80
              	
        if fields["ResultTeam"] == 2 and fields["HeroesCount"] == 6:

            player_data["Trophies"] += 0
            #5на5режим
        if fields["ResultTeam"] == 0 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [642]:

            player_data["Trophies"] += 110
            player_data["HighestTrophies"] += 110
    	
        if fields["ResultTeam"] == 1 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [642]:

            player_data["Trophies"] += 110
            player_data["HighestTrophies"] += 110
              	
        if fields["ResultTeam"] == 2 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [642]:

            player_data["Trophies"] += 0
            
            #парное шд
        if fields["ResultTeam"] <= 2 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [431]:

            player_data["Trophies"] += 70
            player_data["HighestTrophies"] += 70
    	
        if fields["ResultTeam"] >4 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [431]:

            player_data["Trophies"] -= 15
              	
        if fields["ResultTeam"] == 3 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [431]:

            player_data["Trophies"] += 0
            
            #соло шд
        if fields["ResultTeam"] <= 4 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [430]:

            player_data["Trophies"] += 80
            player_data["HighestTrophies"] += 80
    	
        if fields["ResultTeam"] >6 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [430]:
            
            player_data["Trophies"] += 80
            player_data["HighestTrophies"] += 80
              	
        if fields["ResultTeam"] == 5 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [430]:

            player_data["Trophies"] += 0
            
        try:
        	player_data["Logs"]
        except KeyError:
        	player_data["Logs"] = []
        fields["ChallengeReward"] = {}
        fields["ChallengeWin"] = 0
        fields["ChallengeLosses"] = 0
        if fields["ChallengeVariation"] == -1:
        	if fields["Result"] == 0:
        		log = {'Trophies': 80, 'Result': 0, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"])}
        	if fields["Result"] == 1:
        		log = {'Trophies': 80, 'Result': 1, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        	if fields["Result"] == 2:
        		log = {'Trophies': 0, 'Result': 2, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        else:
        	if fields["Result"] == 0:
        		log = {'Trophies': 0, 'Result': 0, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        		try:
        		    player_data["Notifications"]
        		except KeyError:
        			player_data["Notifications"] = []
        		challenge = Configuration.settings["ChallengeLogicName"]
        		for x in Configuration.settings["ChallengeRewards"]:
        			if x["Win"] == player_data["Challenges"][challenge]["Wins"]:
        				if x["Type"] == 1 or x["Type"] == 16 or x["Type"] == 17 or x["Type"] == 28:
        					if x["Type"] == 1:
        						player_data["Coins"] += x["Amount"]
        						fields["RewardCoins"] += x["Amount"]
        					elif x["Type"] == 17:
        						player_data["StarPoints"] += x["Amount"]
        						try:
        							player_data["StarPointsGained"]
        						except KeyError:
        							player_data["StarPointsGained"] = 0 
        						fields["RewardStarPoints"] += x["Amount"]
        					elif x["Type"] == 16:
        						player_data["Gems"] += x["Amount"]
        						try:
        							player_data["GemsGained"]
        						except KeyError:
        							player_data["GemsGained"] = 0 
        						fields["RewardGems"] += x["Amount"]
        					elif x["Type"] == 28:
        						player_data["BPTokens"] += x["Amount"]
        						fields["RewardTokens"] += x["Amount"]
        				if x["Type"] == 19 or x["Type"] == 25 or x["Type"] == 4 or x["Type"] == 6 or x["Type"] == 14 or x["Type"] == 10:
        					notification = {"Type": 63, "Readed": False, "Timer": 999, "Text": "", "Reward": {"Type": x["Type"], "Amount": x["Amount"], "Brawler": x["Brawler"], "Extra": x["Extra"]}, "ChallengeVariation": fields["ChallengeVariation"], "Win": player_data["Challenges"][challenge]["Wins"], "ChallengeName": Configuration.settings["ChallengeName"], "Number": len(player_data["Notifications"]) + 1}
        					player_data["Notifications"].append(notification)
        				fields["ChallengeWin"] = player_data["Challenges"][challenge]["Wins"]
        				fields["ChallengeReward"] = {"Type": x["Type"], "Amount": x["Amount"], "Brawler": x["Brawler"], "Extra": x["Extra"]}
        		if player_data["Challenges"][challenge]["Wins"] == Configuration.settings["ChallengeTotalWins"]:
        			reward = Configuration.settings["ChallengeFinalReward"]
        			if reward["Type"] == 19 or reward["Type"] == 25 or reward["Type"] == 4 or reward["Type"] == 6 or reward["Type"] == 14 or reward["Type"] == 10:
        				notification = {"Type": 63, "Readed": False, "Timer": 999, "Text": "", "Reward": {"Type": reward["Type"], "Amount": reward["Amount"], "Brawler": reward["Brawler"], "Extra": reward["Extra"]}, "ChallengeVariation": fields["ChallengeVariation"], "Win": player_data["Challenges"][challenge]["Wins"], "ChallengeName": Configuration.settings["ChallengeName"], "Number": len(player_data["Notifications"]) + 1}
        				player_data["Notifications"].append(notification)
        	if fields["Result"] == 1:
        		log = {'Trophies': 0, 'Result': 1, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        		challenge = Configuration.settings["ChallengeLogicName"]
        		fields["ChallengeLosses"] = player_data["Challenges"][challenge]["Defeates"]
        	if fields["Result"] == 2:
        		log = {'Trophies': 0, 'Result': 2, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        player_data['Logs'].append(log)
       
        	

        	
        db_instance.updatePlayerData(player_data, calling_instance)
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(23456, fields, cryptoInit, calling_instance.player)

    def getMessageType(self):
        return 14110

    def getMessageVersion(self):
        return self.messageVersion
