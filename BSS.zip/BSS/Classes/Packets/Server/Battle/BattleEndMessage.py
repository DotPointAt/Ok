from Classes.Packets.PiranhaMessage import PiranhaMessage
import random

OwnedBrawlersLatest = {
        0: {'CardID': 0, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        1: {'CardID': 4, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        2: {'CardID': 8, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        3: {'CardID': 12, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        4: {'CardID': 16, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        5: {'CardID': 20, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        6: {'CardID': 24, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        7: {'CardID': 28, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        8: {'CardID': 32, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        9: {'CardID': 36, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        10: {'CardID': 40, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        11: {'CardID': 44, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        12: {'CardID': 48, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        13: {'CardID': 52, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        14: {'CardID': 56, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        15: {'CardID': 60, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        16: {'CardID': 64, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        17: {'CardID': 68, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        18: {'CardID': 72, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        19: {'CardID': 95, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        20: {'CardID': 100, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        21: {'CardID': 105, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        22: {'CardID': 110, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        23: {'CardID': 115, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        24: {'CardID': 120, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        25: {'CardID': 125, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        26: {'CardID': 130, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        27: {'CardID': 177, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        28: {'CardID': 182, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        29: {'CardID': 188, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        30: {'CardID': 194, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        31: {'CardID': 200, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        32: {'CardID': 206, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        34: {'CardID': 218, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        35: {'CardID': 224, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        36: {'CardID': 230, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        37: {'CardID': 236, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        38: {'CardID': 279, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        39: {'CardID': 296, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        40: {'CardID': 303, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        41: {'CardID': 320, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        42: {'CardID': 327, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        43: {'CardID': 334, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        44: {'CardID': 341, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        45: {'CardID': 358, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        46: {'CardID': 365, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        47: {'CardID': 372, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        48: {'CardID': 379, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        49: {'CardID': 386, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        50: {'CardID': 393, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        51: {'CardID': 410, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        52: {'CardID': 417, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        53: {'CardID': 427, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        54: {'CardID': 434, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        56: {'CardID': 448, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        57: {'CardID': 466, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        58: {'CardID': 474, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        59: {'CardID': 491, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        60: {'CardID': 499, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        61: {'CardID': 507, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        62: {'CardID': 515, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        63: {'CardID': 523, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        64: {'CardID': 531, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        65: {'CardID': 539, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        66: {'CardID': 547, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        67: {'CardID': 557, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        68: {'CardID': 565, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        69: {'CardID': 573, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        70: {'CardID': 581, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        71: {'CardID': 589, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        72: {'CardID': 597, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        73: {'CardID': 605, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        74: {'CardID': 619, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        75: {'CardID': 633, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        76: {'CardID': 642, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        77: {'CardID': 655, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
    }

class BattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        
        #три на три режимы
        if fields["ResultTeam"] == 0 and fields["HeroesCount"] == 6:
        	player.TrophiesGained += 80
        	MasteryDa = 1000
        if fields["ResultTeam"] == 1 and fields["HeroesCount"] == 6:
        	player.TrophiesGained += 80
        	MasteryDa = 0
        	MasteryMinus = 0
        if fields["ResultTeam"] == 2 and fields["HeroesCount"] == 6:
        	player.TrophiesGained = 0
        	MasteryDa = 0
        	MasteryMinus = 0
        	
        	#пятьнапять режим
        if fields["ResultTeam"] == 0 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [642]:
        	player.TrophiesGained += 110
        	MasteryDa = 1000
        if fields["ResultTeam"] == 1 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [642]:
        	player.TrophiesGained += 110
        	MasteryDa = 0     	
        if fields["ResultTeam"] == 3 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [642]:
        	player.TrophiesGained = 0
        	MasteryDa = 0
        	MasteryMinus = 0
        	
        	#парное шд
        if fields["ResultTeam"] <= 2 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [431]:
        	player.TrophiesGained += 70
        	MasteryDa = 1000

        	
        if fields["ResultTeam"] >3 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [431]:
        	player.TrophiesGained -= 15
        	MasteryDa = 0

        	
        if fields["ResultTeam"] == 3 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [431]:
        	player.TrophiesGained = 0
        	MasteryDa = 0
        	MasteryMinus = 0
        	
        	#соло шд
        if fields["ResultTeam"] <= 4 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [430]:
        	player.TrophiesGained += 80
        	MasteryDa = 1000

        	
        if fields["ResultTeam"] >5 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [430]:
        	player.TrophiesGained += 90
        	MasteryDa = 0
        	MasteryMinus = 0
        if fields["ResultTeam"] == 5 and fields["HeroesCount"] == 10 and fields["MapID"][1] in [430]:
        	player.TrophiesGained += 90
        	MasteryDa = 0
        	MasteryMinus = 0
        	
        kills = random.randint(1, 10)
        deads = random.randint(0, 3)
        damages = random.randint(10000, 60000)
        
        self.writeLong(0, 1) # Battle UUID High
        self.writeLong(0, 1) # Battle UUID Low
        PlayersTeams = []
        for heroEntry in fields["Heroes"]:
        	PlayersTeams.append(heroEntry["Team"])
        Bot1Team = PlayersTeams[1]
        if fields["HeroesCount"] == 10 and fields["MapID"][1] in [431]:
        	self.writeVInt(2) # Battle End Game Mode
        elif fields["HeroesCount"] == 10 and fields["MapID"][1] in [430]:
        	self.writeVInt(2) # Battle End Game Mode
        elif fields["HeroesCount"] == 10 and fields["MapID"][1] in [642]:
        	self.writeVInt(2) # Battle End Game Mode
        elif fields["HeroesCount"] == 3:
        	self.writeVInt(2) # Battle End Game Mode
        elif fields["HeroesCount"] == 3:
        	self.writeVInt(2) # Battle End Game Mode
        elif fields["HeroesCount"] == 6:
        	self.writeVInt(2) # Battle End Game Mode
        	
        self.writeVInt(fields["Rank"]) # Result (Victory/Defeat/Draw/Rank Score)
        if fields["Result"] == 0:
        	self.writeVInt(0) # Tokens Gained
        	self.writeVInt(8) # Trophies Result
        if fields["Result"] == 1:
        	self.writeVInt(0) # Tokens Gained
        	self.writeVInt(-5) # Trophies Result
        if fields["Result"] == 2:
        	self.writeVInt(0) # Tokens Gained
        	self.writeVInt(0) # Trophies Result
        self.writeVInt(0) # Power Play Points Gained (Pro League Points)
        self.writeVInt(0) # Doubled Tokens (Double Keys)
        self.writeVInt(0) # Double Token Event (Double Event Keys)
        self.writeVInt(0) # Token Doubler Remaining (Double Keys Remaining)
        self.writeVInt(0) # game Lenght In Seconds
        self.writeVInt(0) # Epic Win Power Play Points Gained (op Win Points)
        self.writeVInt(0) # Championship Level Reached (CC Wins)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0) #Coin Event
        self.writeVInt(0) 
        self.writeVInt(16) # Underdog Trophies
        self.writeVInt(16) # SD+ Win Trophies
        self.writeVInt(16) # SD+ Lose Trophies
        self.writeVInt(16) # Battle Result Type
        self.writeBoolean(False)
        self.writeBoolean(True)
        self.writeBoolean(False)
        self.writeBoolean(True) #true
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(1)

        self.writeVInt(fields["HeroesCount"])
        for heroEntry in fields["Heroes"]:
            self.writeBoolean(heroEntry["IsPlayer"])
            self.writeBoolean(bool(heroEntry["Team"]))
            self.writeBoolean(bool(heroEntry["Team"]))
            self.writeByte(1)
            for i in range(1):
                self.writeDataReference(heroEntry["Brawler"]["ID"][0], heroEntry["Brawler"]["ID"][1])
            self.writeByte(1)
            for i in range(1):
                if (heroEntry["Brawler"]["SkinID"] is None):
                    self.writeVInt(0)
                else:
                    self.writeDataReference(heroEntry["Brawler"]["SkinID"][0], heroEntry["Brawler"]["SkinID"][1])
            self.writeByte(1)
            for i in range(1):

                self.writeVInt(1250)
            self.writeByte(1)
            for i in range(1):
                self.writeVInt(11)
            self.writeByte(1)
            for i in range(1):
                self.writeVInt(0)

            self.writeVInt(0)
            self.writeVInt(0)

            self.writeBoolean(heroEntry["IsPlayer"])
            if heroEntry["IsPlayer"]:
                self.writeLong(player.ID[0], player.ID[1])
            self.writeString(heroEntry["PlayerName"])
            self.writeVInt(100)
            self.writeVInt(28000000)
            self.writeVInt(43000000)
            self.writeVInt(-2)
            if heroEntry["IsPlayer"]:
                self.writeBoolean(True)
                self.writeVLong(5, 4181497)
                self.writeString('haccer club')
                self.writeDataReference(8, 16)
            else:
                self.writeBoolean(False)

            self.writeInt8(1)
            for i in range(1):

        	       	if heroEntry["IsPlayer"]:

        	       		for i,v in player.OwnedBrawlers.items():

        	       			if v["CardID"] == OwnedBrawlersLatest[heroEntry["Brawler"]["ID"][1]]["CardID"]:

        	       				self.writeVInt(-1000 + v["Mastery"]) # очки мастерства 
            self.writeInt8(1)
            self.writeVInt(MasteryDa) #da

            self.writeInt16(kills) #kills
            self.writeInt16(deads) #deads
            self.writeInt(damages) #damage
            
            self.writeInt(25659)

            self.writeDataReference(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # 0x0
        self.writeBoolean(False) # 0x0
        self.writeBoolean(False) # 0x0
        self.writeBoolean(False) # 0x0
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # 0x0
        self.writeVInt(0)
        self.writeBoolean(False) # 0x0
        self.writeVInt(0)
        self.writeBoolean(False) # 0x0
        self.writeBoolean(False) # 0x0
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # 0x0
        self.writeBoolean(False) # 0x0
        self.writeBoolean(False) # 0x0
        self.writeVInt(0) #моивмно
  
        
        
        

    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 23456

    def getMessageVersion(self):
        return self.messageVersion