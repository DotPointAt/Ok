import time

from Classes.Packets.PiranhaMessage import PiranhaMessage


class StartLoadingMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
    	
    	
    	#вроде старт лоадинг на 50 версии
    	
    	self.writeInt(1) #players count
    	self.writeInt(0)
    	self.writeInt(0)
    	
    	self.writeInt(1) #players array (хз но да)
    	for i in range(1):
    		self.writeLong(player.ID[0], player.ID[1])  #player id
    		
    		self.writeVInt(1) #team
    		self.writeVInt(0)
    		self.writeVInt(0)
    		
    		self.writeInt(0)
    		
    		self.writeBoolean(True)
    		self.writeDataReference(16, 54)
    		self.writeBoolean(False)
    		self.writeBoolean(False)
    		self.writeBoolean(False)
    		
    		self.writeDataReference(0)
    		self.writeDataReference(0)
    		self.writeVInt(0)
    		
    		self.writeString("kek") #player name
    		
    		self.writeVInt(100)
    		self.writeVInt(28000000) #profile icon
    		self.writeVInt(43000000) #namecolor
    		self.writeVInt(0) #brawl pass color
    		
    		self.writeBoolean(False) #boolean
    		self.writeBoolean(False)
    		self.writeBoolean(False)
    		self.writeVInt(0) #namecolor
    		self.writeVInt(0)
    		self.writeDataReference(0)
    		self.writeDataReference(0)
    		self.writeDataReference(0)
    		self.writeDataReference(0)
    		self.writeVInt(0)
    		#self.writeVInt(0)
    		
    		
    	
    	self.writeInt(0)
    	self.writeInt(0)
    	self.writeInt(0)
    	
    	self.writeVInt(1)
    	self.writeVInt(1)
    	self.writeVInt(1)
    	#self.writeVInt(0)
    	
    	self.writeBoolean(False) 
    	self.writeVInt(1)#is spectating
    	self.writeVInt(0)
    	self.writeDataReference(15, 32) #map
    	self.writeBoolean(False)
    	
    	self.writeBoolean(False)
    	self.writeBoolean(False)
    	self.writeVInt(0)
    	self.writeVInt(0)
        
    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 20559

    def getMessageVersion(self):
        return self.messageVersion