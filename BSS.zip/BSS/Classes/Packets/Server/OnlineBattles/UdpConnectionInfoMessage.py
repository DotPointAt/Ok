from Classes.Packets.PiranhaMessage import PiranhaMessage
class UdpConnectionInfoMessage(PiranhaMessage):

    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
    	self.writeVInt(9339)
    	self.writeString("0.0.0.0")
    	self.writeByte(0)
    	self.writeByte(0)
    	
    def getMessageType(self):
    	return 24112

    def getMessageVersion(self):
    	return self.messageVersion