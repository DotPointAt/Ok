from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage

class MatchMakingStatusMessage(PiranhaMessage):
	def __init__(self, messageData):
	    super().__init__(messageData)
	    self.messageVersion = 0
        
	def encode(self, fields, player):
		self.writeInt(20)
		self.writeInt(1487)#plrs
		self.writeInt(1488)#max plrs
		self.writeInt(0)
		self.writeInt(0)#cancel
		self.writeBoolean(False)
	
	def execute(message, calling_instance, fields):
	    pass
	    
	def getMessageType(self):
	    return 20405
	    
	def getMessageVersion(self):
	    return self.messageVersion