import time

from Classes.Packets.PiranhaMessage import PiranhaMessage


class StartLoadingMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
    	
    	
    	#вроде старт лоадинг на 50 версии
    	
    	self.writeInt(6) #players count
    	self.writeInt(0)
    	self.writeInt(0)
    	
    	self.writeInt(6) #players array (хз но да)
    	for i in range(3):
    		self.writeLong(0, 255)  #player id
    		
    		self.writeVInt(0) #team
    		self.writeVInt(0)
    		self.writeVInt(0)
    		
    		self.writeInt(0)
    		
    		self.writeBoolean(True) #hero update start
    		self.writeDataReference(16, 0)
    		
    		self.writeBoolean(False)
    		#self.writeVInt(0)
    		#self.writeDataReference(0, 0)
    		#self.writeDataReference(0, 0)
    		#self.writeDataReference(0, 0)
    		#self.writeDataReference(0, 0)
    		self.writeBoolean(False)
    		#self.writeVInt(1)
    		#self.writeDataReference(29, 0)
    		#self.writeBoolean(False)
    		#self.writeBoolean(False)
    		self.writeDataReference(0)
    		self.writeDataReference(0)
    		self.writeVInt(0)

    		
    		self.writeString("Online Battles Test") #player name
    		
    		self.writeVInt(100)
    		self.writeVInt(28000000) #profile icon
    		self.writeVInt(43000009) #namecolor
    		self.writeVInt(0) #brawl pass color
    		
    		self.writeBoolean(False) #boolean
    		self.writeBoolean(False)
    		self.writeBoolean(False)
    		self.writeVInt(0)
    		self.writeVInt(0)
    		self.writeDataReference(28, 0)
    		self.writeDataReference(28, 0)
    		self.writeDataReference(52, 0)
    		self.writeDataReference(76, 9)
    		
    		self.writeVInt(0)
    	for i in range(3):
    		self.writeLong(0, 255)  #player id
    		
    		self.writeVInt(1) #team
    		self.writeVInt(0)
    		self.writeVInt(0)
    		
    		self.writeInt(0)
    		
    		self.writeBoolean(True) #hero update start
    		self.writeDataReference(16, 0)
    		
    		self.writeBoolean(False)
    		#self.writeVInt(0)
    		#self.writeDataReference(0, 0)
    		#self.writeDataReference(0, 0)
    		#self.writeDataReference(0, 0)
    		#self.writeDataReference(0, 0)
    		self.writeBoolean(False)
    		#self.writeVInt(1)
    		#self.writeDataReference(29, 0)
    		#self.writeBoolean(False)
    		#self.writeBoolean(False)
    		self.writeDataReference(0)
    		self.writeDataReference(0)
    		self.writeVInt(0)

    		
    		self.writeString("Online Battles Test") #player name
    		
    		self.writeVInt(100)
    		self.writeVInt(28000000) #profile icon
    		self.writeVInt(43000009) #namecolor
    		self.writeVInt(0) #brawl pass color
    		
    		self.writeBoolean(False) #boolean
    		self.writeBoolean(False)
    		self.writeBoolean(False)
    		self.writeVInt(0)
    		self.writeVInt(0)
    		self.writeDataReference(28, 0)
    		self.writeDataReference(28, 0)
    		self.writeDataReference(52, 0)
    		self.writeDataReference(76, 9)
    		
    		self.writeVInt(0)
    		
    	
    	self.writeInt(0)
    	self.writeInt(0)
    	self.writeInt(0)
    	
    	self.writeVInt(0)
    	self.writeVInt(0) #если 0 то карта пустая
    	self.writeVInt(0)
    	self.writeVInt(0)
    	
    	self.writeBoolean(False) #is spectating
    	self.writeVInt(1)
    	self.writeVInt(0)
    	self.writeDataReference(15, 13) #map
    	self.writeBoolean(False)
    	
    	self.writeBoolean(False)
    	self.writeBoolean(False)
    	self.writeVInt(0)
    	self.writeVInt(0)
    	self.writeVInt(0)
    	self.writeVInt(0)
    	self.writeBoolean(False)
        #start loading end
        
    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 20559

    def getMessageVersion(self):
        return self.messageVersion