from Classes.Packets.PiranhaMessage import PiranhaMessage
class VisionUpdateMessage(PiranhaMessage):

    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        self.writeVInt(65535) # Battle Tick
        self.writeVInt(0) # wifi posral jidko
        self.writeVInt(0) # Commands Count
        self.writeVInt(0) # spectators
        self.writeBoolean(False) # Live Boolean
        self.writeBoolean(False)
        self.writeBoolean(False)
        
    def getMessageType(self):
    	return 24109

    def getMessageVersion(self):
    	return self.messageVersion
    	