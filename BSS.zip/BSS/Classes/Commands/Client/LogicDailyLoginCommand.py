import json
from subprocess import call

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler

class LogicDailyLoginCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["GiftID"] = calling_instance.readVInt()
        fields["Choice"] = calling_instance.readVInt()
        fields["Choice1"] = calling_instance.readVInt()
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        if fields["GiftID"] == 1:
            player_data["OwnedSkins"].append(669)
            player_data["delivery_items"] = {'Boxes': []}
            box = {
            'Type': 0,
            'Items': []
            }
            item = {'Amount': 490, 'DataRef': [29, 669],  'RewardID': 9}
            box['Type'] = 100
            box['Items'].append(item)
            player_data["delivery_items"]['Boxes'].append(box)
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
        
        		
   
    		
    	
    def getCommandType(self):
        return 550