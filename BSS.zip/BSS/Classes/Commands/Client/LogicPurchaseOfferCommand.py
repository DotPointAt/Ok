import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStream import ByteStream
import random
from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Classes.Logic.LogicStarrDropData import starrDropOpening
from time import time
import csv
OwnedMicosLatest = { 75: {'CardID': 633, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 11, 'Mastery': 0, 'ClaimRewardsMastery': 0}, }

OwnedBrawlersLatest = {
        0: {'CardID': 0, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        1: {'CardID': 4, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        2: {'CardID': 8, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        3: {'CardID': 12, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        4: {'CardID': 16, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        5: {'CardID': 20, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        6: {'CardID': 24, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        7: {'CardID': 28, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        8: {'CardID': 32, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        9: {'CardID': 36, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        10: {'CardID': 40, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        11: {'CardID': 44, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        12: {'CardID': 48, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        13: {'CardID': 52, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        14: {'CardID': 56, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        15: {'CardID': 60, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        16: {'CardID': 64, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        17: {'CardID': 68, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        18: {'CardID': 72, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        19: {'CardID': 95, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        20: {'CardID': 100, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        21: {'CardID': 105, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        22: {'CardID': 110, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        23: {'CardID': 115, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        24: {'CardID': 120, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        25: {'CardID': 125, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        26: {'CardID': 130, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        27: {'CardID': 177, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        28: {'CardID': 182, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        29: {'CardID': 188, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        30: {'CardID': 194, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        31: {'CardID': 200, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        32: {'CardID': 206, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        34: {'CardID': 218, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        35: {'CardID': 224, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        36: {'CardID': 230, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        37: {'CardID': 236, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        38: {'CardID': 279, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        39: {'CardID': 296, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        40: {'CardID': 303, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        41: {'CardID': 320, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        42: {'CardID': 327, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        43: {'CardID': 334, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        44: {'CardID': 341, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        45: {'CardID': 358, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        46: {'CardID': 365, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        47: {'CardID': 372, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        48: {'CardID': 379, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        49: {'CardID': 386, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        50: {'CardID': 393, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        51: {'CardID': 410, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        52: {'CardID': 417, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        53: {'CardID': 427, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        54: {'CardID': 434, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        56: {'CardID': 448, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        57: {'CardID': 466, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        58: {'CardID': 474, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        59: {'CardID': 491, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        60: {'CardID': 499, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        61: {'CardID': 507, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        62: {'CardID': 515, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        63: {'CardID': 523, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        64: {'CardID': 531, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        65: {'CardID': 539, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        66: {'CardID': 547, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        67: {'CardID': 557, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        68: {'CardID': 565, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        69: {'CardID': 573, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        70: {'CardID': 581, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        71: {'CardID': 589, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        72: {'CardID': 597, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        73: {'CardID': 605, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        74: {'CardID': 619, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        75: {'CardID': 633, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 11, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        76: {'CardID': 642, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        77: {'CardID': 655, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0}
    }

def GetSkinPrice (O00O0O00O0O000O00, OO00OO0O0OO00O0OOOO00OO0O0OO00O0OO="Classes/Commands/Client/skins.txt"):
    def O0000OO0000OOOOO0 (OO0O00O000000O0O0 ):
        O000O0O00000O000O =0
        for OO00OO0O0OOOOOO0O in OO0O00O000000O0O0 :
            O000O0O00000O000O =O000O0O00000O000O *10 +ord (OO00OO0O0OOOOOO0O )-ord ('0')
        return O000O0O00000O000O
    def ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 (O0OOO0000000O00O0 ,O00OO0O00OO0OO000 =10 ,O0O0OOOO00O00O0OO =10 ):
        OOOOO0O0O0O0OOO00 =int (O0OOO0000000O00O0 ,O0O0OOOO00O00O0OO )if isinstance (O0OOO0000000O00O0 ,str )else O0OOO0000000O00O0
        OOO0OOO0OO0O0000O ="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        OO00O0O000OO00O00 =""
        while OOOOO0O0O0O0OOO00 >0 :
            OOOOO0O0O0O0OOO00 ,O00000OOO0O0O0OOO =divmod (OOOOO0O0O0O0OOO00 ,O00OO0O00OO0OO000 )
            OO00O0O000OO00O00 +=OOO0OOO0OO0O0000O [O00000OOO0O0O0OOO ]
        return OO00O0O000OO00O00 [::-1 ]
    with open (f'{OO00OO0O0OO00O0OOOO00OO0O0OO00O0OO}')as OOOO0OOO00OO0OO00 :
        from csv import reader as oh ;OO00OO0O0OO00O0OO =0
        for O0OO000OOOOO00OOO in oh (OOOO0OOO00OO0OO00 ,delimiter =','):
            if (OO00OO0O0OO00O0OO in [ 0, 1]):OO00OO0O0OO00O0OO +=1
            else:
                if OO00OO0O0OO00O0OO -2 ==O00O0O00O0O000O00 :OO00O0O000OO00O00OO0B = int; return [O0000OO0000OOOOO0 (O0OO000OOOOO00OOO [ OO00O0O000OO00O00OO0B(ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789('I', O0O0OOOO00O00O0OO=OO00O0O000OO00O00OO0B("20", 16))) ]),O0000OO0000OOOOO0 (O0OO000OOOOO00OOO [ OO00O0O000OO00O00OO0B(ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789('H', O0O0OOOO00O00O0OO=OO00O0O000OO00O00OO0B("20", 16))) ])]
                if ""!=O0OO000OOOOO00OOO [0 ]:OO00OO0O0OO00O0OO +=1 
                
def GetPinPrice (O00O0O00O0O000O00, OO00OO0O0OO00O0OOOO00OO0O0OO00O0OO="Classes/Commands/Client/emotes.txt"):
    def O0000OO0000OOOOO0 (OO0O00O000000O0O0 ):
        O000O0O00000O000O =0
        for OO00OO0O0OOOOOO0O in OO0O00O000000O0O0 :
            O000O0O00000O000O =O000O0O00000O000O *10 +ord (OO00OO0O0OOOOOO0O )-ord ('0')
        return O000O0O00000O000O
    def ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 (O0OOO0000000O00O0 ,O00OO0O00OO0OO000 =10 ,O0O0OOOO00O00O0OO =10 ):
        OOOOO0O0O0O0OOO00 =int (O0OOO0000000O00O0 ,O0O0OOOO00O00O0OO )if isinstance (O0OOO0000000O00O0 ,str )else O0OOO0000000O00O0
        OOO0OOO0OO0O0000O ="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        OO00O0O000OO00O00 =""
        while OOOOO0O0O0O0OOO00 >0 :
            OOOOO0O0O0O0OOO00 ,O00000OOO0O0O0OOO =divmod (OOOOO0O0O0O0OOO00 ,O00OO0O00OO0OO000 )
            OO00O0O000OO00O00 +=OOO0OOO0OO0O0000O [O00000OOO0O0O0OOO ]
        return OO00O0O000OO00O00 [::-1 ]
    with open (f'{OO00OO0O0OO00O0OOOO00OO0O0OO00O0OO}')as OOOO0OOO00OO0OO00 :
        from csv import reader as oh ;OO00OO0O0OO00O0OO =0
        for O0OO000OOOOO00OOO in oh (OOOO0OOO00OO0OO00 ,delimiter =','):
            if (OO00OO0O0OO00O0OO in [ 0, 1]):OO00OO0O0OO00O0OO +=1
            else:
                if OO00OO0O0OO00O0OO -2 ==O00O0O00O0O000O00 :OO00O0O000OO00O00OO0B = int; return [O0000OO0000OOOOO0 (O0OO000OOOOO00OOO [ OO00O0O000OO00O00OO0B(ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789('I', O0O0OOOO00O00O0OO=OO00O0O000OO00O00OO0B("20", 16))) ]),O0000OO0000OOOOO0 (O0OO000OOOOO00OOO [ OO00O0O000OO00O00OO0B(ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789('H', O0O0OOOO00O00O0OO=OO00O0O000OO00O00OO0B("20", 16))) ])]
                if ""!=O0OO000OOOOO00OOO [0 ]:OO00OO0O0OO00O0OO +=1 

class LogicPurchaseOfferCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        LogicCommand.encode(self, fields)
        self.writeVInt(0)
        self.writeDataReference(0)
        return self.messagePayload
        
        
    def getSkinsID():
        SkinsID = []
        with open('Classes/Commands/Client/skins.txt') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[1].lower() != 'true':
                        SkinsID.append(line_count - 2)
                    if row[0] != "":
                        line_count += 1
     
    def getPinsID():
        EmotesID = []
        with open('Classes/Commands/Client/emotes.txt') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[1].lower() != 'true':
                        EmotesID.append(line_count - 2)
                    if row[0] != "":
                        line_count += 1

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["OfferIndex"] = calling_instance.readVInt()
        fields["Unk2"] = calling_instance.readDataReference()
        fields["CurrencyType"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        miniboxgold = random.randint(7, 59)
        bigboxgold = random.randint(100, 260)
        megaboxgold = random.randint(3000, 5600)
        bigboxpp = random.randint(100, 300)
        
        fields["Socket"] = calling_instance.client
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        #КАТАЛОГ
        
        if fields["OfferIndex"] == 0:
            player_data["OwnedBrawlers"] = OwnedBrawlersLatest
            player_data["PushasedOffers"].append(-148888)
            player_data["delivery_items"] = {
                'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            box['Type'] = 100
            a = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54, 56]
            for x in a:
            	item = {'Amount': 1, 'DataRef': [16, x], 'RewardID': 1}
            	box['Items'].append(item)
            player_data["delivery_items"]['Boxes'].append(box)
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)	
            	
            	
        if fields["OfferIndex"] == 2:
            	player_data["Gems"] += 50
            	player_data["PushasedOffers"].append(789)
            	player_data["delivery_items"] = {
            	'Boxes': []
            	}
            	box = {
                'Type': 0,
                'Items': []
                }
            	item = {'Amount': 50, 'DataRef': [29, 310], 'RewardID': 8}
            	box['Type'] = 100
            	box['Items'].append(item)
            	player_data["delivery_items"]['Boxes'].append(box)
            	db_instance.updatePlayerData(player_data, calling_instance)
            	fields["Socket"] = calling_instance.client
            	fields["Command"] = {"ID": 203}
            	fields["PlayerID"] = calling_instance.player.ID
            	Messaging.sendMessage(24111, fields, cryptoInit)
            	
        if fields["OfferIndex"] == 3:
            	player_data["Coins"] += 2500
            	player_data["Gems"] -= 49
            	player_data["PushasedOffers"].append(1414)
            	player_data["delivery_items"] = {
            	'Boxes': []
            	}
            	box = {
                'Type': 0,
                'Items': []
                }
            	item = {'Amount': 2500, 'DataRef': [29, 310], 'RewardID': 7}
            	box['Type'] = 100
            	box['Items'].append(item)
            	player_data["delivery_items"]['Boxes'].append(box)
            	db_instance.updatePlayerData(player_data, calling_instance)
            	fields["Socket"] = calling_instance.client
            	fields["Command"] = {"ID": 203}
            	fields["PlayerID"] = calling_instance.player.ID
            	Messaging.sendMessage(24111, fields, cryptoInit)	
            	
        if fields["OfferIndex"] == 4:
            	player_data["Coins"] += 200
            	player_data["PushasedOffers"].append(1415)
            	player_data["delivery_items"] = {
            	'Boxes': []
            	}
            	box = {
                'Type': 0,
                'Items': []
                }
            	item = {'Amount': 200, 'DataRef': [29, 310], 'RewardID': 7}
            	box['Type'] = 100
            	box['Items'].append(item)
            	player_data["delivery_items"]['Boxes'].append(box)
            	db_instance.updatePlayerData(player_data, calling_instance)
            	fields["Socket"] = calling_instance.client
            	fields["Command"] = {"ID": 203}
            	fields["PlayerID"] = calling_instance.player.ID
            	Messaging.sendMessage(24111, fields, cryptoInit)
            	
        if fields["OfferIndex"] == 5:
            	player_data["Coins"] += 1488
            	player_data["Gems"] -= 19
            	player_data["PushasedOffers"].append(17652)
            	player_data["delivery_items"] = {
            	'Boxes': []
            	}
            	box = {
                'Type': 0,
                'Items': []
                }
            	item = {'Amount': 1488, 'DataRef': [29, 310], 'RewardID': 7}
            	box['Type'] = 100
            	box['Items'].append(item)
            	player_data["delivery_items"]['Boxes'].append(box)
            	db_instance.updatePlayerData(player_data, calling_instance)
            	fields["Socket"] = calling_instance.client
            	fields["Command"] = {"ID": 203}
            	fields["PlayerID"] = calling_instance.player.ID
            	Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["Unk2"][0] == 52:
            PinID = fields["Unk2"][1]
            Price = GetPinPrice(PinID)
           # вместо этого просто
            if fields["CurrencyType"] == 0:
            	player_data["Gems"] -= Price[0]
            elif fields["CurrencyType"] == 1:
            	player_data["Bling"] -= Price[1]
            else:
            	None
            player_data["delivery_items"] = {
                'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, fields["Unk2"][1]],  'RewardID': 11}
            player_data["OwnedPins"].append(fields["Unk2"][1])
            box['Type'] = 100
            box['Items'].append(item)
            player_data["delivery_items"]['Boxes'].append(box)
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["Unk2"][0] == 28:
            SkinID = fields["Unk2"][1]
            Price = GetSkinPrice(SkinID)
           # вместо этого просто
            if fields["CurrencyType"] == 0:
            	player_data["Gems"] -= 19
            elif fields["CurrencyType"] == 1:
            	player_data["Bling"] -= 750
            else:
            	None
            player_data["delivery_items"] = {
                'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [28, fields["Unk2"][1]],  'RewardID': 11}
            player_data["OwnedSkins"].append(fields["Unk2"][1])
            box['Type'] = 100
            box['Items'].append(item)
            player_data["delivery_items"]['Boxes'].append(box)
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["Unk2"][0] == 29:
            SkinID = fields["Unk2"][1]
            Price = GetSkinPrice(SkinID)
           # вместо этого просто
            if fields["CurrencyType"] == 0:
            	player_data["Gems"] -= 29
            elif fields["CurrencyType"] == 1:
            	player_data["Bling"] -= 1000
            else:
            	None
            player_data["delivery_items"] = {
                'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [29, fields["Unk2"][1]],  'RewardID': 9}
            player_data["OwnedSkins"].append(fields["Unk2"][1])
            box['Type'] = 100
            box['Items'].append(item)
            player_data["delivery_items"]['Boxes'].append(box)
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
       

    def getCommandType(self):
        return 519