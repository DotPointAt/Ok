import json
from Classes.Commands.LogicCommand import LogicCommand
from Database.DatabaseHandler import DatabaseHandler
from Classes.Files.Classes.Cards import Cards
from Classes.Messaging import Messaging

class LogicPognaliCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["UnlockedBrawler"] = calling_instance.readVInt()
        print(fields["UnlockedBrawler"])
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        #player_data["CardsID"].append(Cards().get_unlock_by_brawler_id(fields["UnlockedBrawler"]))
        #print("New Cards ID: ", player_data["CardsID"])
        
        
        if fields["UnlockedBrawler"] == 1:
            player_data["CardsID"].append(4)
            player_data["UnlockingBrawler"] = 3
            player_data["brawlers"].remove(2)
        if fields["UnlockedBrawler"] == 3:
            player_data["CardsID"].append(12)
            player_data["UnlockingBrawler"] = 4
            player_data["brawlers"].remove(4)
        if fields["UnlockedBrawler"] == 4:
            player_data["CardsID"].append(16)
            player_data["UnlockingBrawler"] = 5
            player_data["brawlers"].remove(5)
        if fields["UnlockedBrawler"] == 5:
            player_data["CardsID"].append(20)
            player_data["UnlockingBrawler"] = 6
            player_data["brawlers"].remove(6)
        if fields["UnlockedBrawler"] == 6:
            player_data["CardsID"].append(24)
            player_data["UnlockingBrawler"] = 7
            player_data["brawlers"].remove(7)
        if fields["UnlockedBrawler"] == 7:
            player_data["CardsID"].append(28)
            player_data["UnlockingBrawler"] = 9
            player_data["brawlers"].remove(8)
        if fields["UnlockedBrawler"] == 9:
            player_data["CardsID"].append(36)
            player_data["UnlockingBrawler"] = 10
            player_data["brawlers"].remove(10)
        if fields["UnlockedBrawler"] == 10:
            player_data["CardsID"].append(40)
            player_data["UnlockingBrawler"] = 11
            player_data["brawlers"].remove(11)
        if fields["UnlockedBrawler"] == 11:
            player_data["CardsID"].append(44)
            player_data["UnlockingBrawler"] = 12
            player_data["brawlers"].remove(12)
        if fields["UnlockedBrawler"] == 12:
            player_data["CardsID"].append(48)
            player_data["UnlockingBrawler"] = 13
            player_data["brawlers"].remove(13)
        if fields["UnlockedBrawler"] == 13:
            player_data["CardsID"].append(52)
            player_data["UnlockingBrawler"] = 14
            player_data["brawlers"].remove(14)
        if fields["UnlockedBrawler"] == 14:
            player_data["CardsID"].append(56)
            player_data["UnlockingBrawler"] = 15
            player_data["brawlers"].remove(15)
        if fields["UnlockedBrawler"] == 15:
            player_data["CardsID"].append(60)
            player_data["UnlockingBrawler"] = 16
            player_data["brawlers"].remove(16)
        if fields["UnlockedBrawler"] == 16:
            player_data["CardsID"].append(64)
            player_data["UnlockingBrawler"] = 17
            player_data["brawlers"].remove(17)
        if fields["UnlockedBrawler"] == 17:
            player_data["CardsID"].append(68)
            player_data["UnlockingBrawler"] = 18
            player_data["brawlers"].remove(18)
        if fields["UnlockedBrawler"] == 18:
            player_data["CardsID"].append(72)
            player_data["UnlockingBrawler"] = 19
            player_data["brawlers"].remove(19)
        if fields["UnlockedBrawler"] == 19:
            player_data["CardsID"].append(95)
            player_data["UnlockingBrawler"] = 20
            player_data["brawlers"].remove(20)
        if fields["UnlockedBrawler"] == 20:
            player_data["CardsID"].append(100)
            player_data["UnlockingBrawler"] = 21
            player_data["brawlers"].remove(21)
        if fields["UnlockedBrawler"] == 21:
            player_data["CardsID"].append(105)
            player_data["UnlockingBrawler"] = 22
            player_data["brawlers"].remove(22)
        if fields["UnlockedBrawler"] == 22:
            player_data["CardsID"].append(110)
            player_data["UnlockingBrawler"] = 23
            player_data["brawlers"].remove(23)
        if fields["UnlockedBrawler"] == 23:
            player_data["CardsID"].append(115)
            player_data["UnlockingBrawler"] = 24
            player_data["brawlers"].remove(24)
        if fields["UnlockedBrawler"] == 24:
            player_data["CardsID"].append(120)
            player_data["UnlockingBrawler"] = 25
            player_data["brawlers"].remove(25)
        if fields["UnlockedBrawler"] == 25:
            player_data["CardsID"].append(125)
            player_data["UnlockingBrawler"] = 26
            player_data["brawlers"].remove(26)
        if fields["UnlockedBrawler"] == 26:
            player_data["CardsID"].append(130)
            player_data["UnlockingBrawler"] = 27
            player_data["brawlers"].remove(27)
        if fields["UnlockedBrawler"] == 27:
            player_data["CardsID"].append(177)
            player_data["UnlockingBrawler"] = 28
            player_data["brawlers"].remove(28)
        if fields["UnlockedBrawler"] == 28:
            player_data["CardsID"].append(182)
            player_data["UnlockingBrawler"] = 29
            player_data["brawlers"].remove(29)
        if fields["UnlockedBrawler"] == 29:
            player_data["CardsID"].append(188)
            player_data["UnlockingBrawler"] = 30
            player_data["brawlers"].remove(30)
        if fields["UnlockedBrawler"] == 30:
            player_data["CardsID"].append(194)
            player_data["UnlockingBrawler"] = 31
            player_data["brawlers"].remove(31)
        if fields["UnlockedBrawler"] == 31:
            player_data["CardsID"].append(200)
            player_data["UnlockingBrawler"] = 32
            player_data["brawlers"].remove(32)
        if fields["UnlockedBrawler"] == 32:
            player_data["CardsID"].append(206)
            player_data["UnlockingBrawler"] = 34
            player_data["brawlers"].remove(34)
        if fields["UnlockedBrawler"] == 34:
            player_data["CardsID"].append(218)
            player_data["UnlockingBrawler"] = 36
            player_data["brawlers"].remove(36)
        if fields["UnlockedBrawler"] == 36:
            player_data["CardsID"].append(230)
            player_data["UnlockingBrawler"] = 37
            player_data["brawlers"].remove(37)
        if fields["UnlockedBrawler"] == 37:
            player_data["CardsID"].append(236)
            player_data["UnlockingBrawler"] = 40
            player_data["brawlers"].remove(40)
        if fields["UnlockedBrawler"] == 40:
            player_data["CardsID"].append(303)
            player_data["UnlockingBrawler"] = 42
            player_data["brawlers"].remove(42)
        if fields["UnlockedBrawler"] == 42:
            player_data["CardsID"].append(327)
            player_data["UnlockingBrawler"] = 43
            player_data["brawlers"].remove(43)
        if fields["UnlockedBrawler"] == 43:
            player_data["CardsID"].append(334)
            player_data["UnlockingBrawler"] = 45
            player_data["brawlers"].remove(45)
        if fields["UnlockedBrawler"] == 45:
            player_data["CardsID"].append(358)
            player_data["UnlockingBrawler"] = 47
            player_data["brawlers"].remove(47)
        if fields["UnlockedBrawler"] == 47:
            player_data["CardsID"].append(372)
            player_data["UnlockingBrawler"] = 48
            player_data["brawlers"].remove(48)
        if fields["UnlockedBrawler"] == 48:
            player_data["CardsID"].append(379)
            player_data["UnlockingBrawler"] = 50
            player_data["brawlers"].remove(50)
        if fields["UnlockedBrawler"] == 50:
            player_data["CardsID"].append(393)
            player_data["UnlockingBrawler"] = 52
            player_data["brawlers"].remove(52)
        if fields["UnlockedBrawler"] == 52:
            player_data["CardsID"].append(417)
            player_data["UnlockingBrawler"] = 58
            player_data["brawlers"].remove(58)
        if fields["UnlockedBrawler"] == 58:
            player_data["CardsID"].append(474)
            player_data["UnlockingBrawler"] = 61
            player_data["brawlers"].remove(61)
        if fields["UnlockedBrawler"] == 61:
            player_data["CardsID"].append(507)
            player_data["UnlockingBrawler"] = 63
            player_data["brawlers"].remove(63)
        if fields["UnlockedBrawler"] == 63:
            player_data["CardsID"].append(523)
            player_data["UnlockingBrawler"] = 64
            player_data["brawlers"].remove(64)
        if fields["UnlockedBrawler"] == 64:
            player_data["CardsID"].append(531)
            player_data["UnlockingBrawler"] = 67
            player_data["brawlers"].remove(67)
        if fields["UnlockedBrawler"] == 67:
            player_data["CardsID"].append(557)
            player_data["UnlockingBrawler"] = 69
            player_data["brawlers"].remove(69)
        if fields["UnlockedBrawler"] == 69:
            player_data["CardsID"].append(573)
            player_data["UnlockingBrawler"] = 71
            player_data["brawlers"].remove(71)
        if fields["UnlockedBrawler"] == 71:
            player_data["CardsID"].append(589)
            #player_data["UnlockingBrawler"] = 71
            player_data["IsStarrRoadCompleted"] = 1
            
        rare = [1, 3, 6, 8, 10, 13, 24]
        super_rare = [4, 7, 9, 18, 19, 22, 25, 27, 34, 61]
        epic = [14, 15, 16, 20, 26, 29, 30, 36, 43, 45, 48, 50, 58, 69]
        mythic = [11, 17, 21, 35, 31, 32, 37, 42, 47, 64, 67, 71]
        legendary = [5, 12, 23, 28, 40, 52, 63]
        
        ja = fields["UnlockedBrawler"]
        
        if ja in rare:
            player_data["CurrCredits"] = player_data["CurrCredits"] - 160
        if ja in super_rare:
            player_data["CurrCredits"] = player_data["CurrCredits"] - 430
        if ja in epic:
            player_data["CurrCredits"] = player_data["CurrCredits"] - 925
        if ja in mythic:
            player_data["CurrCredits"] = player_data["CurrCredits"] - 1900
        if ja in legendary:
            player_data["CurrCredits"] = player_data["CurrCredits"] - 3800
        
        
        db_instance.updatePlayerData(player_data, calling_instance)
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 227}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields, cryptoInit)

    def getCommandType(self):
        return 562