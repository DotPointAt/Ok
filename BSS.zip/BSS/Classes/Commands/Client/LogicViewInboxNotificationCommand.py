import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStream import ByteStream
import random
from Classes.Packets.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage


class LogicViewInboxNotificationCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["NotificationIndex"] = calling_instance.readVInt()
        fields["ChoiceCalendar"] = calling_instance.readVInt()
        fields["brawler"] = [16,35]
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        RandomChinaThemeID = random.randint(89, 93)
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])

        	
        if fields["NotificationIndex"] == 1:
        	player_data["ThemeID"] = RandomChinaThemeID
        	    
        	player_data["delivery_items"] = {
                'Boxes': []
            }
        	box = {
        	'Type': 0,
        	'Items': []
        	}
        	
        	item = {'Amount': 1, 'DataRef': [16, fields["brawler"][1]],  'RewardID': 1}
        	box['Type'] = 100
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	Messaging.sendMessage(24104, fields, cryptoInit)
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        	
        if fields["NotificationIndex"] == 0:
        	player_data["delivery_items"] = {
                'Boxes': []
            }
        	box = {
        	'Type': 0,
        	'Items': []
        	}
        	box['Type'] = 100
        	item = {'Amount': 250, 'DataRef': [28, 79], 'RewardID': 25}
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        	
        if fields["NotificationIndex"] == 2:
        	if player_data["BrawlPassSeason"] == 22:
        	    player_data["BrawlPassSeason"] += 1
        	    player_data["ThemeID"] = 85
        	else:
        	    player_data["BrawlPassSeason"] -= 1
        	    player_data["ThemeID"] = 86
        	player_data["delivery_items"] = {
                'Boxes': []
            }
        	box = {
        	'Type': 0,
        	'Items': []
        	}
        	
        	item = {'Amount': 1, 'DataRef': [16, fields["brawler"][1]],  'RewardID': 1}
        	box['Type'] = 100
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	Messaging.sendMessage(24104, fields, cryptoInit)
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        else:
        	pass


    def getCommandType(self):
        return 528