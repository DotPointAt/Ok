from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import json

class LogicChangeBattleMapCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["BrawlerID"] = calling_instance.readDataReference()
        fields["CardID"] = calling_instance.readDataReference()
        fields["Unk2"] = calling_instance.readVInt()
        fields["Unk1"] = calling_instance.readVInt()
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        if fields["CardID"][0] == 76:
            calling_instance.player.title = fields["CardID"][1]
            player_data["Title"] = fields["CardID"][1]
        if fields["CardID"][0] == 52:
            calling_instance.player.pin = fields["CardID"][1]
            player_data["BattlePin"] = fields["CardID"][1]
        if fields["CardID"][0] == 28 and fields["Unk1"] == 0:
            calling_instance.player.icon1 = fields["CardID"][1]
            player_data["BattleIcon1"] = fields["CardID"][1]
        if fields["CardID"][0] == 28 and fields["Unk1"] == 1:
            calling_instance.player.icon2 = fields["CardID"][1]
            player_data["BattleIcon2"] = fields["CardID"][1]
            
        db_instance.updatePlayerData(player_data, calling_instance)

    def getCommandType(self):
        return 568