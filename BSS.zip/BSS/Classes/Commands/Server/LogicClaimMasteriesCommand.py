from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import json

OwnedBrawlersLatest = {
        0: {'CardID': 0, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        1: {'CardID': 4, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        2: {'CardID': 8, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        3: {'CardID': 12, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        4: {'CardID': 16, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        5: {'CardID': 20, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        6: {'CardID': 24, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        7: {'CardID': 28, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        8: {'CardID': 32, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        9: {'CardID': 36, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        10: {'CardID': 40, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        11: {'CardID': 44, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        12: {'CardID': 48, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        13: {'CardID': 52, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        14: {'CardID': 56, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        15: {'CardID': 60, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        16: {'CardID': 64, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        17: {'CardID': 68, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        18: {'CardID': 72, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        19: {'CardID': 95, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        20: {'CardID': 100, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        21: {'CardID': 105, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        22: {'CardID': 110, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        23: {'CardID': 115, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        24: {'CardID': 120, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        25: {'CardID': 125, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        26: {'CardID': 130, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        27: {'CardID': 177, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        28: {'CardID': 182, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        29: {'CardID': 188, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        30: {'CardID': 194, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        31: {'CardID': 200, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        32: {'CardID': 206, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        34: {'CardID': 218, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        35: {'CardID': 224, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        36: {'CardID': 230, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        37: {'CardID': 236, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        38: {'CardID': 279, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        39: {'CardID': 296, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        40: {'CardID': 303, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        41: {'CardID': 320, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        42: {'CardID': 327, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        43: {'CardID': 334, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        44: {'CardID': 341, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        45: {'CardID': 358, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        46: {'CardID': 365, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        47: {'CardID': 372, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        48: {'CardID': 379, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        49: {'CardID': 386, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        50: {'CardID': 393, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        51: {'CardID': 410, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        52: {'CardID': 417, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        53: {'CardID': 427, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        54: {'CardID': 434, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        56: {'CardID': 448, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        57: {'CardID': 466, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        58: {'CardID': 474, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        59: {'CardID': 491, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        60: {'CardID': 499, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        61: {'CardID': 507, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        62: {'CardID': 515, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        63: {'CardID': 523, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        64: {'CardID': 531, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        65: {'CardID': 539, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        66: {'CardID': 547, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        67: {'CardID': 557, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        68: {'CardID': 565, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        69: {'CardID': 573, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        70: {'CardID': 581, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        71: {'CardID': 589, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        72: {'CardID': 597, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        73: {'CardID': 605, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        74: {'CardID': 619, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        75: {'CardID': 633, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        76: {'CardID': 642, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        77: {'CardID': 655, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    }
    
class LogicClaimMasteriesCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        fields["tick1"] = calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["brawler"] = calling_instance.readDataReference()
        fields["reward"] = calling_instance.readVInt()
        print(fields["brawler"])
        print(fields["reward"])
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        if fields["brawler"][1] == 0 or fields["brawler"][1] == 1 or fields["brawler"][1] == 8 or fields["brawler"][1] == 6 or fields["brawler"][1] == 10 or fields["brawler"][1] == 3 or fields["brawler"][1] == 13 or fields["brawler"][1] == 24 or fields["brawler"][1] == 2 or fields["brawler"][1] == 7 or fields["brawler"][1] == 9 or fields["brawler"][1] == 27 or fields["brawler"][1] == 22 or fields["brawler"][1] == 14 or fields["brawler"][1] == 30 or fields["brawler"][1] == 15 or fields["brawler"][1] == 45 or fields["brawler"][1] == 16 or fields["brawler"][1] == 20 or fields["brawler"][1] == 26 or fields["brawler"][1] == 29 or fields["brawler"][1] == 36 or fields["brawler"][1] == 35 or fields["brawler"][1] == 39 or fields["brawler"][1] == 43 or fields["brawler"][1] == 48 or fields["brawler"][1] == 50 or fields["brawler"][1] == 51 or fields["brawler"][1] == 53 or fields["brawler"][1] == 60 or fields["brawler"][1] == 58 or fields["brawler"][1] == 61 or fields["brawler"][1] == 65 or fields["brawler"][1] == 68 or fields["brawler"][1] == 73 or fields["brawler"][1] == 72 or fields["brawler"][1] == 69 or fields["brawler"][1] == 77:
            if fields["reward"] == 2:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 750, 'DataRef': [0, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 750
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            
                
                
            if fields["reward"] == 3:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 100, 'DataRef': [16, 0],  'RewardID': 24}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["PowerPoints"] += 100
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1          
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 4:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 75, 'DataRef': [16, 0],  'RewardID': 22}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Fame"] += 75
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 5:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 200, 'DataRef': [16, 0],  'RewardID': 24}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["PowerPoints"] += 200
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 6:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 1250, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 1250
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 7:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 150, 'DataRef': [16, 0],  'RewardID': 22}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Fame"] += 150
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 8:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 50, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 50
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 9:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 50, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 50
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1        
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 10:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 1, 'DataRef': [71, 77],  'RewardID': 10}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["OwnedTitles"] += [fields["brawler"][1]]
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24104, fields, cryptoInit)
                Messaging.sendMessage(24111, fields, cryptoInit)
               
                #мифики
        if fields["brawler"][1] == 11 or fields["brawler"][1] == 17 or fields["brawler"][1] == 21 or fields["brawler"][1] == 32 or fields["brawler"][1] == 31 or fields["brawler"][1] == 37 or fields["brawler"][1] == 42 or fields["brawler"][1] == 41 or fields["brawler"][1] == 47 or fields["brawler"][1] == 44 or fields["brawler"][1] == 49 or fields["brawler"][1] == 54 or fields["brawler"][1] == 56 or fields["brawler"][1] == 57 or fields["brawler"][1] == 59 or fields["brawler"][1] == 62 or fields["brawler"][1] == 64 or fields["brawler"][1] == 66 or fields["brawler"][1] == 67 or fields["brawler"][1] == 71 or fields["brawler"][1] == 73 or fields["brawler"][1] == 74 or fields["brawler"][1] == 75 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 90 or fields["brawler"][1] == 98 or fields["brawler"][1] == 99 or fields["brawler"][1] == 98 or fields["brawler"][1] == 93 or fields["brawler"][1] == 99 or fields["brawler"][1] == 97:
            if fields["reward"] == 2:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 1000, 'DataRef': [0, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 1000
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
                
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 3:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 150, 'DataRef': [16, 0],  'RewardID': 24}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["PowerPoints"] += 150
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 4:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 100, 'DataRef': [16, 0],  'RewardID': 22}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Fame"] += 100
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 5:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 300, 'DataRef': [16, 0],  'RewardID': 24}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["PowerPoints"] += 300
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
                
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 6:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 2000, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 2000
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 7:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 200, 'DataRef': [16, 0],  'RewardID': 22}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Fame"] += 200
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 8:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 100, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 100
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 9:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 100, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 100
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 10:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 1, 'DataRef': [71, 77],  'RewardID': 10}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["OwnedTitles"] += [fields["brawler"][1]]
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24104, fields, cryptoInit)
                Messaging.sendMessage(24111, fields, cryptoInit)
                
                #леги 5 12 23 28 38 52 40
        if fields["brawler"][1] == 5 or fields["brawler"][1] == 12 or fields["brawler"][1] == 23 or fields["brawler"][1] == 28 or fields["brawler"][1] == 38 or fields["brawler"][1] == 52 or fields["brawler"][1] == 40 or fields["brawler"][1] == 76 or fields["brawler"][1] == 63 or fields["brawler"][1] == 70 or fields["brawler"][1] == 99 or fields["brawler"][1] == 94 or fields["brawler"][1] == 96 or fields["brawler"][1] == 97 or fields["brawler"][1] == 159 or fields["brawler"][1] == 622 or fields["brawler"][1] == 642 or fields["brawler"][1] == 266 or fields["brawler"][1] == 627 or fields["brawler"][1] == 271 or fields["brawler"][1] == 273 or fields["brawler"][1] == 274 or fields["brawler"][1] == 275 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 99 or fields["brawler"][1] == 90 or fields["brawler"][1] == 98 or fields["brawler"][1] == 99 or fields["brawler"][1] == 98 or fields["brawler"][1] == 93 or fields["brawler"][1] == 99 or fields["brawler"][1] == 97:
            if fields["reward"] == 2:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 1000, 'DataRef': [0, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 1000
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 3:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 150, 'DataRef': [16, 0],  'RewardID': 24}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["PowerPoints"] += 150
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
            if fields["reward"] == 4:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 100, 'DataRef': [16, 0],  'RewardID': 22}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Fame"] += 100
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 5:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 300, 'DataRef': [16, 0],  'RewardID': 24}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["PowerPoints"] += 300
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
                
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 6:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 2000, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 2000
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 7:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 200, 'DataRef': [16, 0],  'RewardID': 22}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Fame"] += 200
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 8:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 100, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 100
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 9:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 100, 'DataRef': [16, 0],  'RewardID': 7}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["Coins"] += 100
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
            
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
            if fields["reward"] == 10:
                player_data["delivery_items"] = {
                    'Boxes': []
                }
                box = {
            	'Type': 0,
            	'Items': []
            	}
                item = {'Amount': 1, 'DataRef': [71, 77],  'RewardID': 10}
                box['Type'] = 100
                box['Items'].append(item)
                player_data["delivery_items"]['Boxes'].append(box)
                player_data["OwnedTitles"] += [fields["brawler"][1]]
                for i,v in player_data["OwnedBrawlers"].items():
                    if v["CardID"] == OwnedBrawlersLatest[fields["brawler"][1]]["CardID"]:
                        v["ClaimRewardsMastery"] += 1         
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24104, fields, cryptoInit)
                Messaging.sendMessage(24111, fields, cryptoInit)

    def getCommandType(self):
        return 569