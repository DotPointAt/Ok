from Classes.Commands.LogicServerCommand import LogicServerCommand
from Classes.ByteStreamHelper import ByteStreamHelper
from Static.StaticData import StaticData

import time

from Database.DatabaseHandler import DatabaseHandler
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Utility import Utility
from Static.StaticData import StaticData
from Classes.Files.Classes.Cards import Cards
import Configuration


class LogicDayChangedCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])

        self.writeVInt(36) # event slot id
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(3)
        self.writeVInt(4)
        self.writeVInt(5)
        self.writeVInt(6)
        self.writeVInt(7)
        self.writeVInt(8)
        self.writeVInt(9)
        self.writeVInt(10)
        self.writeVInt(11)
        self.writeVInt(12)
        self.writeVInt(13) 
        self.writeVInt(14)
        self.writeVInt(15)
        self.writeVInt(16)
        self.writeVInt(17)
        self.writeVInt(18) 
        self.writeVInt(19)
        self.writeVInt(20)
        self.writeVInt(21) 
        self.writeVInt(22)
        self.writeVInt(23)
        self.writeVInt(24)
        self.writeVInt(25)
        self.writeVInt(26)
        self.writeVInt(27)
        self.writeVInt(28)
        self.writeVInt(29)
        self.writeVInt(30)
        self.writeVInt(31)
        self.writeVInt(32)
        self.writeVInt(33)
        self.writeVInt(34) #гиперзаряд событие
        self.writeVInt(35) #мега копилка
        self.writeVInt(37)

        Events = [{7, 54}, {8, 82}, {265, 9}]
        EventIndex = 1

        EventsData = Events[player_data["EventData"]]
        
        self.writeVInt(len(EventsData)) # Events Count(7 it a ChampionShip(3 Stages) and ClubLeague(PowerMatch and Default Game Mode)) and PowerLeague(Solo and Team Mode)
        for i in EventsData:
              # Default Slots Start Array #
              self.writeVInt(4)
              self.writeVInt(EventIndex)  # EventType
              EventIndex += 1
              self.writeVInt(0)  # EventsBeginCountdown
              self.writeVInt(0)
              self.writeVInt(0)  # Timer
              self.writeVInt(0)  # tokens reward for new event
              self.writeDataReference(15, i)  # MapID
              self.writeVInt(-64)  # GameModeVariation
              self.writeVInt(0)  # Status
              self.writeString()
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False)  # Map Maker Map Structure Array
              self.writeVInt(0)
              self.writeBoolean(False)  # Power League Data Array
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False)  # ChronosTextEntry
              self.writeBoolean(False)
              self.writeBoolean(False)
              self.writeVInt(-1)
              self.writeBoolean(False)
              self.writeBoolean(False)
              self.writeVInt(-1)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False)
              # Default Slots End Array #

        self.writeVInt(0) # Comming Events

        ByteStreamHelper.encodeIntList(self, [20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800])
        ByteStreamHelper.encodeIntList(self, [30, 80, 170, 360]) # Shop Coins Price
        ByteStreamHelper.encodeIntList(self, [300, 880, 2040, 4680]) # Shop Coins Amount

        self.writeVInt(0)

        self.writeVInt(3) # IntValueEntr
        self.writeVLong(41000000 + player.ThemeID, 1)
        self.writeVLong(0, 112) #мастерство без границ
        self.writeVLong(1, 110)

        self.writeVInt(0)
        
        self.writeVInt(0)
        
        self.writeVInt(0)
        self.writeVInt(0)
        LogicServerCommand.encode(self, fields)
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        fields["Unk1"] = calling_instance.readString()
        fields["Unk2"] = calling_instance.readVInt()
        return LogicServerCommand.decode(calling_instance, fields)

    def getCommandType(self):
        return 204