from Classes.ByteStream import ByteStream
#from Classes.Logic.LogicBoxData import LogicBoxData
from Classes.Commands.LogicServerCommand import LogicServerCommand
from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import json
import random

OwnedBrawlersLatest = {
        0: {'CardID': 0, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        1: {'CardID': 4, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        2: {'CardID': 8, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        3: {'CardID': 12, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        4: {'CardID': 16, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        5: {'CardID': 20, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        6: {'CardID': 24, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        7: {'CardID': 28, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        8: {'CardID': 32, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        9: {'CardID': 36, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        10: {'CardID': 40, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        11: {'CardID': 44, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        12: {'CardID': 48, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        13: {'CardID': 52, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        14: {'CardID': 56, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        15: {'CardID': 60, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        16: {'CardID': 64, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        17: {'CardID': 68, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        18: {'CardID': 72, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        19: {'CardID': 95, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        20: {'CardID': 100, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        21: {'CardID': 105, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        22: {'CardID': 110, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        23: {'CardID': 115, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        24: {'CardID': 120, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        25: {'CardID': 125, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        26: {'CardID': 130, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        27: {'CardID': 177, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        28: {'CardID': 182, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        29: {'CardID': 188, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        30: {'CardID': 194, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        31: {'CardID': 200, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        32: {'CardID': 206, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        34: {'CardID': 218, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        35: {'CardID': 224, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        36: {'CardID': 230, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        37: {'CardID': 236, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        38: {'CardID': 279, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        39: {'CardID': 296, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        40: {'CardID': 303, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        41: {'CardID': 320, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        42: {'CardID': 327, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        43: {'CardID': 334, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        44: {'CardID': 341, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        45: {'CardID': 358, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        46: {'CardID': 365, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        47: {'CardID': 372, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        48: {'CardID': 379, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        49: {'CardID': 386, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        50: {'CardID': 393, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        51: {'CardID': 410, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        52: {'CardID': 417, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        53: {'CardID': 427, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        54: {'CardID': 434, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        56: {'CardID': 448, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        57: {'CardID': 466, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        58: {'CardID': 474, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        59: {'CardID': 491, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        60: {'CardID': 499, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        61: {'CardID': 507, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        62: {'CardID': 515, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        63: {'CardID': 523, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        64: {'CardID': 531, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        65: {'CardID': 539, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        66: {'CardID': 547, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        67: {'CardID': 557, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        68: {'CardID': 565, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        69: {'CardID': 573, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        70: {'CardID': 581, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        71: {'CardID': 589, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        72: {'CardID': 597, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        73: {'CardID': 605, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        74: {'CardID': 619, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        75: {'CardID': 633, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        76: {'CardID': 642, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
        77: {'CardID': 655, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 9},
    }


class LogicLevelUpCommand(LogicServerCommand):
    
    def __init__(self, commandData):
        super().__init__(commandData)

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["BrawlerID"] = calling_instance.readDataReference()
        LogicCommand.parseFields(fields)
        return fields

    def encode(self, fields):
    	pass

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        brawler = fields["BrawlerID"][1]
        player_data["OwnedBrawlers"][f'{brawler}']['PowerLevel'] = player_data["OwnedBrawlers"][f'{brawler}']['PowerLevel'] + 1
        db_instance.updatePlayerData(player_data, calling_instance)
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 206}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields, cryptoInit)


    def getCommandType(self):
        return 520



