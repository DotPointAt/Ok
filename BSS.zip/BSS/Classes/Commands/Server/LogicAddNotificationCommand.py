from random import choice
import json
from Classes.Messaging import Messaging
from Classes.Commands.LogicServerCommand import LogicServerCommand
from Classes.Commands.LogicCommand import LogicCommand
from Database.DatabaseHandler import DatabaseHandler
from Classes.Messaging import Messaging
from Classes.Instances.Classes.Player import Player

class LogicAddNotificationCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)
    
    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        #fields["Unk1"] = calling_instance.readVInt()
#        fields["Unk2"] = calling_instance.readVInt()
#        fields["Unk3"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields
        
    def encode(self, fields):
        None
        
    def getCommandType(self):
        return 206
        
        