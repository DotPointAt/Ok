import json

from Classes.Commands.LogicServerCommand import LogicServerCommand

from Classes.Messaging import Messaging

from Database.DatabaseHandler import DatabaseHandler


class LogicSetSupportedCreatorCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        text=fields["SupportedCreator"]
        self.writeVInt(1)
        self.writeString(text)
        LogicServerCommand.encode(self, fields)
        return self.messagePayload

    def getCommandType(self):
        return 215