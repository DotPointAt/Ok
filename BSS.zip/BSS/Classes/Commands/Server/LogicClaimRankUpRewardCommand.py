import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStream import ByteStream
import random
from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging

from time import time

BrawlerPins = {
    0: {'Common': [152, 154, 210], 'Rare': [153, 499], 'Epic': [155, 266]},
    1: {'Common': [45, 47, 190], 'Rare': [46, 471], 'Epic': [48, 241, 272]},
    2: {'Common': [35, 37, 188], 'Rare': [36, 466], 'Epic': [38, 239]},
    3: {'Common': [30, 32, 187], 'Rare': [31, 465], 'Epic': [33, 238]},
    4: {'Common': [136, 138, 207], 'Rare': [137, 495], 'Epic': [139, 263]},
    5: {'Common': [160, 162, 211], 'Rare': [161, 500], 'Epic': [163, 267]},
    6: {'Common': [8, 10, 183], 'Rare': [9, 460], 'Epic': [11, 234]},
    7: {'Common': [89, 91, 198], 'Rare': [90, 482], 'Epic': [92, 251]},
    8: {'Common': [105, 107, 201], 'Rare': [106, 489], 'Epic': [108, 257]},
    9: {'Common': [60, 62, 193], 'Rare': [61, 474], 'Epic': [63, 244]},
    10: {'Common': [130, 132, 206], 'Rare': [131, 494], 'Epic': [133, 262]},
    11: {'Common': [100, 102, 200], 'Rare': [101, 486], 'Epic': [103, 254]},
    12: {'Common': [50, 52, 191], 'Rare': [51, 472], 'Epic': [53, 242]},
    13: {'Common': [125, 127, 205], 'Rare': [126, 493], 'Epic': [128, 261, 274]},
    14: {'Common': [24, 26, 186], 'Rare': [25, 464], 'Epic': [27, 237]},
    15: {'Common': [120, 122, 204], 'Rare': [121, 492], 'Epic': [123, 260]},
    16: {'Common': [110, 112, 202], 'Rare': [111, 490], 'Epic': [113, 258]},
    17: {'Common': [171, 173, 213], 'Rare': [172, 505], 'Epic': [174, 269, 276]},
    18: {'Common': [55, 57, 192], 'Rare': [56, 473], 'Epic': [58, 243]},
    19: {'Common': [115, 117, 203], 'Rare': [116, 491], 'Epic': [118, 259]},
    20: {'Common': [71, 73, 195], 'Rare': [72, 477], 'Epic': [74, 246]},
    21: {'Common': [77, 79, 196], 'Rare': [78, 479], 'Epic': [80, 249]},
    22: {'Common': [178, 180, 214], 'Rare': [179, 506], 'Epic': [181, 270]},
    23: {'Common': [95, 97, 199], 'Rare': [96, 483], 'Epic': [98, 252]},
    24: {'Common': [141, 143, 208], 'Rare': [142, 496], 'Epic': [144, 264]},
    25: {'Common': [40, 42, 189], 'Rare': [41, 469], 'Epic': [43, 240, 271]},
    26: {'Common': [18, 20, 185], 'Rare': [19, 463], 'Epic': [21, 236]},
    27: {'Common': [1, 3, 182], 'Rare': [2, 458], 'Epic': [4, 233]},
    28: {'Common': [147, 149, 209], 'Rare': [148, 498], 'Epic': [150, 265, 275]},
    29: {'Common': [13, 15, 184], 'Rare': [14, 461], 'Epic': [16, 235]},
    30: {'Common': [66, 68, 194], 'Rare': [67, 476], 'Epic': [69, 245, 273]},
    31: {'Common': [284, 286, 287], 'Rare': [285, 487], 'Epic': [255, 288]},
    32: {'Common': [278, 280, 281], 'Rare': [279, 485], 'Epic': [253, 282]},
    34: {'Common': [84, 86, 197], 'Rare': [85, 481], 'Epic': [87, 250]},
    35: {'Common': [216, 218, 219], 'Rare': [217, 478], 'Epic': [220, 247]},
    36: {'Common': [228, 230, 231], 'Rare': [229, 488], 'Epic': [232, 256, 360]},
    37: {'Common': [165, 167, 212], 'Rare': [166, 501], 'Epic': [168, 268]},
    38: {'Common': [290, 292, 302], 'Rare': [291, 504], 'Epic': [301, 303, 304]},
    39: {'Common': [306, 308, 310], 'Rare': [307, 470], 'Epic': [309, 311]},
    40: {'Common': [321, 323, 325], 'Rare': [322, 459], 'Epic': [324, 326, 327]},
    41: {'Common': [346, 348, 358], 'Rare': [347, 484], 'Epic': [357, 359, 360]},
    42: {'Common': [379, 381, 383], 'Rare': [380, 468], 'Epic': [382, 384, 385]},
    43: {'Common': [370, 372, 374], 'Rare': [371, 475], 'Epic': [373, 375, 376]},
    44: {'Common': [386, 388, 390], 'Rare': [387, 497], 'Epic': [389, 391, 392]},
    45: {'Common': [408, 410, 412], 'Rare': [409, 503], 'Epic': [411, 413, 414]},
    46: {'Common': [416, 418, 420], 'Rare': [417, 462], 'Epic': [419, 421, 422]},
    47: {'Common': [431, 434, 436], 'Rare': [433, 502], 'Epic': [435, 437, 438]},
    48: {'Common': [595, 596, 599], 'Rare': [597, 602], 'Epic': [598, 600, 601]},
    49: {'Common': [440, 441, 444], 'Rare': [442, 467], 'Epic': [443, 445, 446]},
    50: {'Common': [448, 451, 454], 'Rare': [449, 480], 'Epic': [450, 452, 453]},
    51: {'Common': [525, 526, 529], 'Rare': [527, 532], 'Epic': [528, 530, 531]},
    52: {'Common': [553, 555, 557], 'Rare': [554, 560], 'Epic': [556, 558, 559]},
    53: {'Common': [568, 569, 572], 'Rare': [570, 575], 'Epic': [571, 573, 574]},
    54: {'Common': [628, 629, 632], 'Rare': [630, 635], 'Epic': [631, 633, 634]},
    56: {'Common': [659, 660, 663], 'Rare': [661, 666], 'Epic': [662, 664, 665]},
    57: {'Common': [689, 690, 693], 'Rare': [691, 696], 'Epic': [692, 694, 695]},
    58: {'Common': [699, 700, 703], 'Rare': [701, 706], 'Epic': [702, 704, 705]},
    59: {'Common': [739, 740, 743], 'Rare': [741, 746], 'Epic': [742, 744, 745]}
}

class LogicClaimRankUpRewardCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def decode(self, calling_instance):
        fields = {}
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        #calling_instance.readVInt()
        fields["RoadID"] = calling_instance.readVInt()
        fields["isbrawler"] = calling_instance.readVInt()
        if fields["isbrawler"] == 0:
            fields["bp_season"] = calling_instance.readVInt()
            fields["LVL"] = calling_instance.readVInt()
        else:
        	fields["brawler"] = calling_instance.readVInt()
        	fields["bp_season"] = calling_instance.readVInt()
        	fields["LVL"] = calling_instance.readVInt()
        	
        	
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        print(fields["RoadID"])
        print(fields["isbrawler"])
        print(fields["bp_season"])
        print(fields["LVL"])
        
        player_data['RewardForRanks'] = fields['LVL']
        player_data['RewardTrackType'] = fields['RoadID']
        player_data['BrawlPassSeasons'] = fields['bp_season']

        if fields["LVL"] < 30 and fields["RoadID"] == 10:
            player_data["BrawlPass1LVL32"] += (2**(fields["LVL"]+2))
            player_data["IsCycle"] = True
        elif fields["LVL"] < 30 and fields["RoadID"] == 9:
            player_data["BrawlPassLVL32"] += (2**(fields["LVL"]+2))                                             
            player_data["IsCycle"] = True
        elif fields["LVL"] >= 30 and fields["LVL"] < 61 and fields["RoadID"] == 9:
            player_data["BrawlPassLVL64"] += (2**(fields["LVL"] - 30))
            player_data["IsCycle"] = True
            
            
            
            
            print(player_data["BrawlPassLVL96"])
         
        
        credits = [0, 4, 8, 12, 16, 20, 25, 30, 33, 38, 43, 49, 54, 58, 63, 68]
        coems = [3, 6, 9, 13, 18, 24, 28, 32, 37, 41, 45, 48, 51, 56, 60, 67]
        coems2000 = []
        chromacredits60 = [7]
        chromacredits40 = [11, 17, 21, 27, 31, 35, 40, 46, 55, 59, 65]
        gems10 = [2, 14, 36, 44, 52]
        gems20 = [22, 62]
        PowerPointsDef = [1, 10, 15, 19, 23, 26, 29, 34, 39, 42, 47, 50, 53, 57, 61, 64, 66, 69]
        powerPoints240 = []
        
        #brawl pass premium
        
        coins = [3, 6, 9, 13, 16, 19, 23, 26, 34, 38, 42, 48, 46, 52, 60, 20, 43, 62, 68, 53,55,57,59,61,63,65,67,69]
        
        
        pps = [1, 4, 7, 11, 14, 17, 21, 24, 27, 29, 39, 44, 54, 58]
        
        credits1 = [2, 5, 8, 12, 15, 18, 22, 25, 28, 32, 36, 40, 47, 50, 56, 64]

                
        if fields["RoadID"] == 9 and fields["LVL"] == 64:
                player_data['BrawlPassLVL96'] = player_data['BrawlPassLVL96'] + 4
                player_data['Fame'] = player_data['Fame'] + 45
                player_data["delivery_items"] = {
                'Boxes': []
                }
                box = {
                'Type': 0,
                'Items': []
                }
                item = {'Amount': 45, 'DataRef': [0, 0], 'RewardID': 22} # Credits
                box['Items'].append(item)
                box['Type'] = 100
                calling_instance.player.BrawlPassLVL96 += 4
                player_data["delivery_items"]['Boxes'].append(box)
                db_instance.updatePlayerData(player_data, calling_instance)
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 203}
                fields["PlayerID"] = calling_instance.player.ID
                Messaging.sendMessage(24111, fields, cryptoInit)
                
        if fields["RoadID"] == 9 and fields["LVL"] == 62: # Coins
                player_data["delivery_items"] = {
                'Boxes': []
                }
                box = {
                'Type': 0,
                'Items': []
                }
                item = {'Amount': 335, 'DataRef': [0, 0], 'RewardID': 7} # Gold
                box['Items'].append(item)
                box['Type'] = 100
                calling_instance.player.BrawlPassLVL96 += 1
                player_data['BrawlPassLVL96'] = player_data['BrawlPassLVL96'] + 1
                player_data['Coins'] = player_data['Coins'] + 335
        if fields["RoadID"] == 9 and fields["LVL"] == 66: # Coins
                player_data["delivery_items"] = {
                'Boxes': []
                }
                box = {
                'Type': 0,
                'Items': []
                }
                item = {'Amount': 180, 'DataRef': [0, 0], 'RewardID': 7} # Gold
                box['Items'].append(item)
                box['Type'] = 100
                calling_instance.player.BrawlPassLVL96 += 1
                player_data['BrawlPassLVL96'] = player_data['BrawlPassLVL96'] + 1
                player_data['Coins'] = player_data['Coins'] + 335
                
        if fields["RoadID"] == 9 and fields["LVL"] == 10:
        	player_data["delivery_items"] = {'Boxes': []}
        	brawlers = list(player_data["OwnedBrawlers"].keys())
        	brawler1 = int(random.choice(brawlers))
        	brawler2 = int(random.choice(brawlers))
        	brawler3 = int(random.choice(brawlers))
        	pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        	pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        	while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        	    pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        	while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        	    pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        	if random.randint(1, 3) == 3:
        	    pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        	    while pin3 in player_data["OwnedPins"]:
        	        pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        	        while pin3 in player_data["OwnedPins"]:
        	            pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        	player_data["OwnedPins"].append(pin1)
        	player_data["OwnedPins"].append(pin2)
        	player_data["OwnedPins"].append(pin2)
        	item = {'Amount': 1, 'DataRef': [52, pin1], 'RewardID': 11}
        	box = {'Type': 100, 'Items': []}
        	box['Items'].append(item)
        	item = {'Amount': 1, 'DataRef': [52, pin2], 'RewardID': 11}
        	box['Items'].append(item)
        	item = {'Amount': 1, 'DataRef': [52, pin2], 'RewardID': 11}
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        	
        if fields["RoadID"] == 10 and fields["LVL"] == 70:
        	player_data["delivery_items"] = {'Boxes': []}
        	brawlers = list(player_data["OwnedBrawlers"].keys())
        	brawler1 = int(random.choice(brawlers))
        	brawler2 = int(random.choice(brawlers))
        	brawler3 = int(random.choice(brawlers))
        	pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        	pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        	while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        	    pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        	while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        	    pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        	if random.randint(1, 3) == 3:
        	    pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        	    while pin3 in player_data["OwnedPins"]:
        	        pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        	        while pin3 in player_data["OwnedPins"]:
        	            pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        	player_data["OwnedPins"].append(pin1)
        	player_data["OwnedPins"].append(pin2)
        	player_data["OwnedPins"].append(pin2)
        	item = {'Amount': 1, 'DataRef': [52, pin1], 'RewardID': 11}
        	box = {'Type': 100, 'Items': []}
        	box['Items'].append(item)
        	item = {'Amount': 1, 'DataRef': [52, pin2], 'RewardID': 11}
        	box['Items'].append(item)
        	item = {'Amount': 1, 'DataRef': [52, pin2], 'RewardID': 11}
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
      
        if fields["RoadID"] == 9 and fields["LVL"] == 30: 
        	player_data["OwnedBrawlers"][65] = {'CardID': 539, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2}
        	player_data["delivery_items"] = {'Boxes': []}
        	box = {'Type': 100, 'Items': []}
        	item = {'Amount': 0, 'DataRef': [16, 65],  'RewardID': 1}
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        
        if fields["RoadID"] == 9 and fields["LVL"] in credits1: 
        	player_data["Fame"] += 45
        	player_data["delivery_items"] = {'Boxes': []}
        	box = {'Type': 100, 'Items': []}
        	item = {'Amount': 45, 'DataRef': [0, 0],  'RewardID': 22}
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        
        if fields["RoadID"] == 9 and fields["LVL"] in pps: 
        	player_data["PowerPoints"] += 150
        	player_data["delivery_items"] = {'Boxes': []}
        	box = {'Type': 100, 'Items': []}
        	item = {'Amount': 150, 'DataRef': [0, 0],  'RewardID': 24}
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        
        if fields["RoadID"] == 9 and fields["LVL"] in coins: 
        	player_data["Coins"] += 335
        	player_data["delivery_items"] = {'Boxes': []}
        	box = {'Type': 100, 'Items': []}
        	item = {'Amount': 335, 'DataRef': [0, 0],  'RewardID': 7}
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        
        if fields["RoadID"] == 9 and fields["LVL"] == 0:
        	player_data["Coins"] += 150
        	player_data["delivery_items"] = {'Boxes': []}
        	box = {'Type': 100, 'Items': []}
        	item = {'Amount': 150, 'DataRef': [0, 0],  'RewardID': 7}
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
        	
        if fields["RoadID"] == 9 and fields["LVL"] == 70:
        	player_data["Coins"] += 50
        	player_data["delivery_items"] = {'Boxes': []}
        	box = {'Type': 100, 'Items': []}
        	item = {'Amount': 50, 'DataRef': [0, 0],  'RewardID': 7}
        	box['Items'].append(item)
        	player_data["delivery_items"]['Boxes'].append(box)
        	db_instance.updatePlayerData(player_data, calling_instance)
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 203}
        	fields["PlayerID"] = calling_instance.player.ID
        	Messaging.sendMessage(24111, fields, cryptoInit)
            
        	
        
        
        if fields["RoadID"] == 10 and fields["LVL"] in credits:
            player_data["Fame"] += 160
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 160, 'DataRef': [0, 0],  'RewardID': 22}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 10 and fields["LVL"] in coems:
            
            player_data["Coins"] += 585
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 585, 'DataRef': [0, 0],  'RewardID': 7}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
            #пины на бойца из бп
            
        if fields["RoadID"] == 9 and fields["LVL"] == 31:
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, 914],  'RewardID': 11}
            player_data["OwnedPins"].append(914)
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 9 and fields["LVL"] == 33:
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, 917],  'RewardID': 11}
            player_data["OwnedPins"].append(917)
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 9 and fields["LVL"] == 45:
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, 915],  'RewardID': 11}
            player_data["OwnedPins"].append(915)
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        
        if fields["RoadID"] == 9 and fields["LVL"] == 41:
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, 919],  'RewardID': 11}
            player_data["OwnedPins"].append(919)
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
             
        if fields["RoadID"] == 9 and fields["LVL"] == 49:
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, 916],  'RewardID': 11}
            player_data["OwnedPins"].append(916)
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 9 and fields["LVL"] == 35:
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, 920],  'RewardID': 11}
            player_data["OwnedPins"].append(920)
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 9 and fields["LVL"] == 53:
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, 921],  'RewardID': 11}
            player_data["OwnedPins"].append(921)
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 9 and fields["LVL"] == 37:
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, 913],  'RewardID': 11}
            player_data["OwnedPins"].append(913)
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 9 and fields["LVL"] == 51:
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 1, 'DataRef': [52, 918],  'RewardID': 11}
            player_data["OwnedPins"].append(918)
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 10 and fields["LVL"] in coems2000:
            
            player_data["Coins"] += 2000
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 2000, 'DataRef': [0, 0],  'RewardID': 7}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 10 and fields["LVL"] in chromacredits60:
            
            player_data["Coins"] += 60
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 60, 'DataRef': [0, 0],  'RewardID': 7}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 10 and fields["LVL"] in chromacredits40:
            
            player_data["ChromaCredits"] += 40
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 40, 'DataRef': [0, 0],  'RewardID': 23}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 10 and fields["LVL"] in gems10:
            
            player_data["Gems"] += 10
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 10, 'DataRef': [0, 0],  'RewardID': 8}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 10 and fields["LVL"] in gems20:
            
            player_data["Gems"] += 20
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 20, 'DataRef': [0, 0],  'RewardID': 8}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 10 and fields["LVL"] == 5:
            
            player_data["PowerPoints"] += 190
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 190, 'DataRef': [0, 0],  'RewardID': 24}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
            
        if fields["RoadID"] == 10 and fields["LVL"] in PowerPointsDef:
            
            player_data["PowerPoints"] += 160
            
            player_data["delivery_items"] = {
            'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            item = {'Amount': 160, 'DataRef': [0, 0],  'RewardID': 24}
            box['Items'].append(item)
            box['Type'] = 100
            player_data["delivery_items"]['Boxes'].append(box)
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 203}
            fields["PlayerID"] = calling_instance.player.ID
            Messaging.sendMessage(24111, fields, cryptoInit)
        

    def getCommandType(self):
        return 517