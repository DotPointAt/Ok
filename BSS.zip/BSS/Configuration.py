
# DisableNagle: reduce delay and improve performance between client and server BUT require more power #

BannedIPs = []

settings = {
    "DisableNagle": True,
    "PrintEnabled": True,
    "UseContentUpdater": False,
    "Maintance": False,
    "MaintanceTime": 0,
    "Tag": "GQP8J2PLY",
    "CreatorsCodesKittys": ["pppqqq", "pq"],
    "CreatorsCodesCats": ["pq", "pppqqq", "poland"],
    "ApiToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6IjAzY2U2Y2ZhLTVhMzctNGJlZi1hNWYyLWM0NzIxOTFiZjdjOCIsImlhdCI6MTcxMzcwMzUwOSwic3ViIjoiZGV2ZWxvcGVyLzQyMmQ4MjdmLWU5YjMtZjVlOS1jYTZhLWQyMDQxNGJkYzJhYiIsInNjb3BlcyI6WyJicmF3bHN0YXJzIl0sImxpbWl0cyI6W3sidGllciI6ImRldmVsb3Blci9zaWx2ZXIiLCJ0eXBlIjoidGhyb3R0bGluZyJ9LHsiY2lkcnMiOlsiNDUuNjEuMTYxLjE5OCIsIjAuMC4wLjAiXSwidHlwZSI6ImNsaWVudCJ9XX0.Y9gPwVgxD-6Zv_7Fnz-Y33dcmSYJe7NTh4xNP5BNHJWHI1VCI6OM8wjOcCxGrqJKpbQlIaADbOKxiFGsQ80kSA",
    "UpdateURL": "https://t.me/bssmaker/",
    "Theme": 0,
    "SkinPack": 18,
    "DoubleTokenEvent": True,
    "GoldRushEvent": False,
    "CurrentBPSeason": 12,
    "MysteryModeEnabled": True,
    "MysteryModeModifiersEnabled": True,
    "MysteryModeMaps": [32, 45, 93, 105, 109, 154, 166, 224, 272],
    "MysteryModeName": "Solo Showdown and Modifiers",
    "ChallengeEnabled": True,
    "ChallengeLives": 4,
    "ChallengeLogicName": "badrandoms_challenge",
    "ChallengeVariation": 7,
    "ChallengeName": "Bad Randoms Challenge",
    "ChallengeStages": 3,
    "ChallengeTotalWins": 9,
    "ChallengeMaps": [4, 479, 12, 0, 0, 0, 0, 0, 0, 0],
    "ChallengeMapsWins": [3, 3, 3, 0, 0, 0, 0, 0, 0, 0],
    "ChallengeFinalReward": {"Type": 25, "Amount": 1, "Brawler": [0, 0], "Extra": 125},
    "ChallengeRewards": [{"Win": 1,"Type": 1, "Amount": 100, "Brawler": [0, 0], "Extra": 0}, {"Win": 2, "Type": 1, "Amount": 100, "Brawler": [0, 0], "Extra": 0}, {"Win": 3, "Type": 6, "Amount": 1, "Brawler": [0, 0], "Extra": 0}, {"Win": 4, "Type": 28, "Amount": 250, "Brawler": [0, 0], "Extra": 0}, {"Win": 5, "Type": 28, "Amount": 250, "Brawler": [0, 0], "Extra": 0}, {"Win": 6, "Type": 14, "Amount": 1, "Brawler": [0, 0], "Extra": 0}, {"Win": 7, "Type": 17, "Amount": 500, "Brawler": [0, 0], "Extra": 0}, {"Win": 8, "Type": 17, "Amount": 500, "Brawler": [0, 0], "Extra": 0}, {"Win": 9, "Type": 10, "Amount": 1, "Brawler": [0, 0], "Extra": 0}],
    "Proxy": False,
    "DumpPacket": False,
    "Blacklist": [24109],
    "DumpMajor": 53
}
