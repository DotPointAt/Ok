from Classes.ServerConnection import ServerConnection
import Configuration
from Static.StaticData import StaticData
from datetime import datetime

StaticData.Preload()


ServerConnection(("0.0.0.0", 9339))